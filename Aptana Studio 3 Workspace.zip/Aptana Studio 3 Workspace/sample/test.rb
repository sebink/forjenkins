str1 = "ca,no,sg,us"
str2 = "sg,no,ca,us,ee"

str3 = str1.split(",")
str3.each do |s|
if(str2.include? s )&& (str1.length == str2.length)
    puts 1 
    else
    puts 0
  end
end
puts str3
puts str1.casecmp str2
