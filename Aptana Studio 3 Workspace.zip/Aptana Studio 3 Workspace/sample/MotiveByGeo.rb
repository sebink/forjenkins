require 'nokogiri'
require 'open-uri'
require 'spreadsheet'
require 'rspec'
require 'rubyXL'
require 'roo'

  @xmlarr = []
  @xcelarr = []
  @coutryTargeting=[]
  @devices = []
  @motiveCid= ""
  @motiveofferid=""
  @name = ""
  @desc = ""
  @campxls = []
  Spreadsheet.client_encoding = 'UTF-8'
  dateTime = ((Time.new).strftime("%Y-%m-%d %H.%M")).to_s
  book = Spreadsheet.open('/Users/sebibbaby/Desktop/clist.xls')
  #book = RubyXL::Parser.parse('/Users/sebibbaby/Desktop/clist.xls')
  book1 = Spreadsheet.open('/Users/sebibbaby/Desktop/Motive_Camp_Status.xls')
  @doc = (Nokogiri::XML(open("http://motivefeed.com/affiliate/campaigns_v2?api_key=LstKht1GD0&affiliate_id=64104.xml")))
  modifiedFile = "/Users/sebibbaby/Google Drive/QA/Automation Test Results/Partner Campaign Analysis/Motive/#{dateTime}.xls"
  @mcamp = book1.worksheet(0)
  @sheet1 = book.worksheet(0)
  @sheet2 = book.worksheet(1)
  @xmlString = @doc.inspect()
  #format = Spreadsheet::Format.new :color=> :blue, :pattern_fg_color => :red, :pattern => 1,:size => 18
  #@sheet2.row(1).set_format(0, format)
 
 @sheet2[0,0] = "Country"
 @sheet2[0,1] = "Campaign Name"
 @sheet2[0,2] = "Campaign Id"
 @sheet2[0,3] = "Offer Id"
 @sheet2[0,4] = "Devices"
 @sheet2[0,5] = "Payout"
 @sheet2[0,6] = "Description"
 
 def getdata
   @mcamp.each 1 do |row|
  break if row[0].nil? # if first cell empty
  @campxls<< row[1]
  end 
 end
 
 def gettingOutAlreadyExistingCamps(link)
  @campxls.each do |camp|
    return true if link.include? camp.to_s
    end
   false   
end
 
  def takingValues 
  @sheet1.each do |row|
  break if row[0].nil? # if first cell empty
  @xcelarr<< row
  end
  #puts @xcelarr
  
  end
 
 def checkingCountryOnXml
        #puts @doc
        @xcelarr.each_with_index do  |item,ind|
          #puts @sheet2.last_row_index+1
           #@sheet2[@sheet2.last_row_index+1,0] = item[0] + "-" + item[1]
            @doc.xpath('//campaign').each do |xml|
             trakingLink   = xml.at('tracking_link').text
                xml.xpath("allowed_countries/allowed_country").each do |t| 
                  #puts t.text
                  payout = xml.xpath('payout').text
                  puts gettingOutAlreadyExistingCamps(trakingLink)
                    if (((t.text == item[1].to_s) && (payout[1..5].to_f >= 2.00) == true) && (gettingOutAlreadyExistingCamps(trakingLink) == false))#(checkingPayOut(payout) == true))
                      #puts item[1]
                          #@coutryTargeting<<t.text.downcase
                          
                          xml.xpath("allowed_devices/allowed_device").each do |d|
                          @devices<<d.text
                          end
                          @motiveCid = xml.xpath("campaign_id").text
                     
                          @motiveofferid = xml.xpath("offer_id").text
                    
                          @name = xml.xpath("offer_name").text
                          @desc = xml.xpath("app_details/content").text
                          puts @desc
                          
                           @sheet2[@sheet2.last_row_index+1,1] = @name
                           @sheet2[@sheet2.last_row_index,0] = item[0] + "-" + item[1]
                           @sheet2[@sheet2.last_row_index,2] = @motiveCid
                           @sheet2[@sheet2.last_row_index,3] = @motiveofferid  
                           @sheet2[@sheet2.last_row_index,4]=@devices.join(",")
                           @sheet2[@sheet2.last_row_index,5]=payout   
                           @sheet2[@sheet2.last_row_index,6]=@desc
                           
                          
                          @coutryTargeting.clear
                          @devices.clear
                          @motiveCname = ""
                          @motiveCname = ""
                          @motiveCname= ""
                          @desc = ""
          end
      end
    end
  end
 end
 
 getdata
 takingValues
 checkingCountryOnXml

 book.write modifiedFile

