require 'rubygems'
require "selenium-webdriver"
require "rspec"
require 'spreadsheet'
require 'open-uri'
require 'countries'
include RSpec::Expectations

describe "AppiaCampExact" do

  before(:all) do
    
    
    @driver = Selenium::WebDriver.for :firefox
    
    @driver.manage().window().maximize()

    @base_url = "https://via.appia.com/login.html"
    @accept_next_alert = true
    @driver.manage.timeouts.implicit_wait = 5
    @verification_errors = []
    @wait = Selenium::WebDriver::Wait.new(:timeout => 30)
    
    
    @book1 = Spreadsheet::Workbook.new
    @sheet2 = @book1.create_worksheet(:name => 'Appia')

    @dest_folder = File.dirname(__FILE__)
    @dateTime = ((Time.new).strftime("%Y-%m-%d %H.%M")).to_s
    @modifiedFile = "/Users/sebibbaby/Google Drive/QA/Partner Campaign Extraction/Appia #{@dateTime}.xls" 
    @book = Spreadsheet.open('/Users/sebibbaby/Google Drive/QA/SQL Scripts/Exports/Appia_Camp_Status.xls')
    @sheet1 = @book.worksheet(0)
    @filename = "/Users/sebibbaby/Google Drive/QA/Automation Test Results/appia_images/100_100/"
    @filenametab = "/Users/sebibbaby/Google Drive/QA/Automation Test Results/appia_images/tablet/"
    
   @sheet2[0,0] = "Campaign Name"
   @sheet2[0,1] = "Campaign Id"
   @sheet2[0,2] = "Status"
   @sheet2[0,3] = "Geo"
   @sheet2[0,4] = "Platform"
   @sheet2[0,5] = "Pay Out"
   @sheet2[0,6] = "Daily Cap"
   @sheet2[0,7] = "Remaining Daily Cap"
   @sheet2[0,8] = "Remaining Total Budget"
   @sheet2[0,9] = "Min OS Version"
   @sheet2[0,10] = "Max OS Version"
   @sheet2[0,11] = "Excluded Devices"
   @sheet2[0,12] = "Category"
   @sheet2[0,13] = "Description"
   @sheet2[0,14] = "URL"
    
    @xcelarr = []
    @allActiveCamp = []
    @platform =[]
    @geo = []
    @imgarray = []
    @imagesurls = []
    @imagetaburl = []
    @countrylist = []
  end
  
  after(:all) do
    @driver.quit
    #FileUtils.cp(@modifiedFile, @dest_folder)
  end


  it "Checking" do
    
    gettingDataFromXml
    
    #puts @xcelarr
    
    @driver.get(@base_url)
    @wait.until { @driver.find_element(:xpath => "//*[@id='emailAddress']").displayed? }
    @driver.find_element(:xpath, "//*[@id='emailAddress']").clear
    @driver.find_element(:xpath, "//*[@id='emailAddress']").click
    @driver.find_element(:xpath, "//*[@id='emailAddress']").send_keys "hsipe@breaktimestudios.com"
    
    @driver.find_element(:xpath, "//*[@id='password']").clear
    @driver.find_element(:xpath, "//*[@id='password']").click
    @driver.find_element(:xpath, "//*[@id='password']").send_keys "appia123"
    
    @driver.find_element(:xpath, "//*[@id='loginButton']").click
    @wait.until { @driver.find_element(:xpath => "html/body/nav/div[2]/ul[1]/li[1]/a").displayed? }
    
    @driver.get("https://via.appia.com/manualDashboard.html")
    
    @wait.until { @driver.find_element(:xpath => "//*[@id='filters']/div[2]/div/button").displayed? }
    
    gettingInformationsFromAppiaWebSite("Active")
    sleep 3
    gettingInformationsFromAppiaWebSite("Pending")
    sleep 3
    
    gettingGeosAndPlatforms
    
    
    @book1.write 'text1.xls' #@modifiedFile#"test1.xls"
  
  downloadfiles
  end  
    
 def gettingInformationsFromAppiaWebSite(stat)
      
    @driver.find_element(:xpath,"(//button[@type='button'])[4]").click
    sleep 2
    @driver.find_element(:link, stat).click
    sleep 5
    @driver.find_element(:xpath, "html/body/div[2]/div[1]/div/header/h1/span").click
    sleep 3
    
      if(stat=="Active")
       @wait.until { @driver.find_element(:xpath, "//*[@id='viewAll']").displayed? }
       @driver.find_element(:xpath, "//*[@id='viewAll']").click
       sleep 50
    end

    gettingDataFromAPI
    
  end


 def gettingDataFromXml
  
      @sheet1.each 1 do |row|
      break if row[0].nil? # if first cell empty
      @xcelarr<< row[1].to_s
 
     end
  end
  
 def gettingDataFromAPI
    
    numberOfGames = @driver.find_elements(:xpath,"//*[@id='campaigns']/tbody/tr").size()
    puts numberOfGames
    if numberOfGames > 0
       for i in 1..numberOfGames
         
          status = @driver.find_element(:xpath, "//*[@id='campaigns']/tbody/tr[#{i}]/td[2]").text
          id = @driver.find_element(:xpath, "//*[@id='campaigns']/tbody/tr[#{i}]/td[3]").text
          name = @driver.find_element(:xpath, "//*[@id='campaigns']/tbody/tr[#{i}]/td[4]").text
          payout = (@driver.find_element(:xpath, "//*[@id='campaigns']/tbody/tr[#{i}]/td[6]").text)[1..-1].to_f
          dailycap = (@driver.find_element(:xpath, "//*[@id='campaigns']/tbody/tr[#{i}]/td[7]").text)
          remainingDailyCap = (@driver.find_element(:xpath, "//*[@id='campaigns']/tbody/tr[#{i}]/td[8]").text)
          totalbudget = (@driver.find_element(:xpath, "//*[@id='campaigns']/tbody/tr[#{i}]/td[9]").text)
          
         if gettingOutAlreadyExistingCamps(id) == false && payout >= 2.00
             
             @sheet2[@sheet2.last_row_index+1,0] = name
             @sheet2[@sheet2.last_row_index,1] = id
             @sheet2[@sheet2.last_row_index,2] = status  
             @sheet2[@sheet2.last_row_index,5] = payout
             @sheet2[@sheet2.last_row_index,6] = dailycap
             @sheet2[@sheet2.last_row_index,7] = remainingDailyCap
             @sheet2[@sheet2.last_row_index,8] = totalbudget
             @allActiveCamp<<id
             
            end   
        end                       
     end
  end
    
 def gettingGeosAndPlatforms
      
         @allActiveCamp.each_with_index  do |id,index|
                 @driver.get("https://via.appia.com/campaign.html?campaignId=#{id}")
                 @wait.until{@driver.find_element(:xpath,"//*[@id='notification-switch']/div/label").displayed?}
                 #sleep 3
                 numberOfCountries = @driver.find_elements(:xpath,'//*[@id="countries"]/li').size() 
                    
                    for i in 1..numberOfCountries
                      cName = @driver.find_element(:xpath, "//*[@id='countries']/li[#{i}]").text
                      @platform<<cName
                      
                  end
                  desc = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[1]/div/div/p[2]").text
                  category = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[1]/div/div/p[1]").text
                  if @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[5]/td[1]").text == "Min OS Version"
                     minOsVersion = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[5]/td[2]").text
                   else
                     minOsVersion = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[6]/td[2]").text
                  end    
                  
                  if @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[6]/td[1]").text == "Max OS Version"
                     maxOsVersion = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[6]/td[2]").text
                   else
                     maxOsVersion = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[7]/td[2]").text
                  end                                         
                  
                  if @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[2]/td[2]").text =="iOS"
                    get(index)
                  else
                    get(index)
                     @sheet2[index+1,4] = "Android"
                        if @sheet2[index+1,11].nil? || @sheet2[index+1,11] == ""
                            @sheet2[index+1,11] = "None"
                        end
                  end
                   #puts platform
                   @sheet2[index+1,3] = @platform.join(',')
                   @sheet2[index+1,9] = minOsVersion
                   @sheet2[index+1,10] = maxOsVersion
                   @sheet2[index+1,13] = desc
                   @sheet2[index+1,12] = category
                   
                   @platform.clear
                   @geo.clear
          end
          
   end
   
 def get(index)
     puts @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[1]").text
     if @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[1]").text == "Excluded Devices"
       #if (element_present?(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[2]/ul/li'") == true)||(element_present?(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[9]/td[2]/ul/li'") == true) 
        
         numberOfDevices = @driver.find_elements(:xpath,'html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[2]/ul/li').size() 
         if numberOfDevices>0
         puts numberOfDevices
          for i in 1..numberOfDevices
                      pName = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[2]/ul/li[#{i}]").text
                      @geo<<pName
            end          
                   end
                   else
                    
                     numberOfDevices = @driver.find_elements(:xpath,'html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[9]/td[2]/ul/li').size() 
                     if numberOfDevices>0
                      puts numberOfDevices
                     for i in 1..numberOfDevices
                      pName = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[9]/td[2]/ul/li[#{i}]").text
                      @geo<<pName  
                    end
                   end 
                  end
                  @sheet2[index+1,11] = @geo.join(',')
                  if @geo.include? 'Apple iPhone'
                    @sheet2[index+1,4] = "iPad" 
                   end
                   if @geo.include? 'Apple iPad' 
                     @sheet2[index+1,4] = "iPhone"
                   end
                  if @sheet2[index+1,4].nil?
                    @sheet2[index+1,4] = "iPhone,iPad"
                  end
               #end   
            end
   def downloadfiles
     @allActiveCamp.length
     @allActiveCamp.each_with_index  do |id,index|
                 @driver.get("https://via.appia.com/campaign.html?campaignId=#{id}")
                 @wait.until{@driver.find_element(:xpath,"//*[@id='notification-switch']/div/label").displayed?}
                    cName = @driver.find_element(:xpath, "//*[@id='countries']/li[1]").text
                    if cName =="Great Britain (UK)"
                        cName = "United Kingdom"
                     end
                       c = Country.find_country_by_name(cName)
                       puts c
                      @countrylist<<c.alpha2
                 if @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[1]").text == "Store Page"
                   link = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[2]/a").attribute("href")
                   @sheet2[index+1,14] = link
                   @imgarray<<link.to_s+"+"+id.to_s
                 else
                   link = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[7]/td[2]/a").attribute("href")
                   @sheet2[index+1,14] = link
                   @imgarray<<link.to_s+"+"+id.to_s
                 end
            end
        callingappstore
   end
   
   def callingappstore
     
     @imgarray.each_with_index  do |link,ind|
       link1 = link.split("+").first
       id1 = link.split("+").last
       @driver.get(link1)
      sleep 2
      
      if link.include? 'itunes'
         link1 = link.split("+").first
        id1 = link.split("+").last
        namse=link1[25..26]
        puts link1.gsub(namse,@countrylist[ind])
        @driver.get(link1)
        if @driver.find_elements(:xpath, "html/body/div[3]/div[2]/div/div/div[1]/p").size()>0
        urlios = @driver.find_element(:xpath,"html/body/div[3]/div[2]/div/div/div[3]/div[1]/a[1]/div/img").attribute("src")
        puts size = @driver.find_elements(:xpath,"html/body/div[3]/div[2]/div/div/div[2]/div[4]/div[2]/div[1]/div").size()
                                                  #html/body/div[3]/div[2]/div/div/div[2]/div[4]/div[2]/div[2]/div[1]
                                                  
        for i in 1..size
          if @driver.find_elements(:xpath,"html/body/div[3]/div[2]/div/div/div[2]/div[4]/div[2]/div[1]/div[#{i}]/img").size()>0
          @imagetaburl<<@driver.find_element(:xpath,"html/body/div[3]/div[2]/div/div/div[2]/div[4]/div[2]/div[1]/div[#{i}]/img").attribute("src")+"++"+id1+"_#{i}"
          end
        end
        @imagesurls<<urlios+"++"+id1
      end
      end
      if link.include? 'google'
           link1 = link.split("+").first
        id1 = link.split("+").last
        @driver.get(link1)
       urlgoogle = @driver.find_element(:xpath,"html/body/div[5]/div[6]/div[1]/div[1]/div[1]/img").attribute("src")
       @imagesurls<<urlgoogle+"++"+id1
      end
    end  
    puts @imagesurls   
    donwloadimages(@imagesurls,@filename) 
    donwloadimages(@imagetaburl,@filenametab) 
    
  end 
  
  def donwloadimages(arr,type)
    arr.each  do |link|
          link1 = link.split("++").first
           id1 = link.split("++").last
          #link.gsub!('[',' ')
          #link.gsub!(']',' ')
          url = URI.parse(URI.encode(link1).strip)
          ext=link
      
  begin
      open(type+id1+".png", 'wb') do |file|
      file << open(url).read
    end
    rescue OpenURI::HTTPError
      #redirect_to :back, notice: 'link's broken！'
    end
  end
end    
 def gettingOutAlreadyExistingCamps(link)
  
      return true if @xcelarr.include? link
      false   
    end   

 def element_present?(how, what)
      
      @driver.find_element(how, what)
      true
      
      rescue Selenium::WebDriver::Error::NoSuchElementError
      false
      
    end
  
 def alert_present?()
      
      @driver.switch_to.alert
      true
      rescue Selenium::WebDriver::Error::NoAlertPresentError
      false
      
    end
  
 def verify(&blk)
      yield
      rescue ExpectationNotMetError => ex
      @verification_errors << ex
      
    end
  
 def close_alert_and_get_its_text(how, what)
      alert = @driver.switch_to().alert()
      alert_text = alert.text
      if (@accept_next_alert) then
        alert.accept()
      else
        alert.dismiss()
      end
      alert_text
    ensure
      @accept_next_alert = true
  end
end
