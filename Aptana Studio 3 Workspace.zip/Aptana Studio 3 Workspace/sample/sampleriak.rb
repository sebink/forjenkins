 require 'riak'
 require 'rubygems'
require 'json'
 
client = Riak::Client.new(:protocol => "pbc", :pb_port => 8087)

my_bucket = client.bucket("test")


val1 = 13242
obj1 = my_bucket.new('one')
obj1.data = val1
obj1.store()

val2 = "two"
obj2 = my_bucket.new('two')
obj2.data = val2
obj2.store()

val3 = { myValue: 3 }
obj3 = my_bucket.new('three')
obj3.data = val3
obj3.store()


fetched1 = my_bucket.get('one')
fetched2 = my_bucket.get('two')
fetched3 = my_bucket.get('three')

book = {
    :isbn => '1111979723',
    :title => 'Moby Dick',
    :author => 'Herman Melville',
    :body => 'Call me Ishmael. Some years ago...',
    :copies_owned => 3
}

book1 = {
    :isbn => '1111979724',
    :title => 'Moby Dick',
    :author => 'Herman Melville',
    :body => 'Call me Ishmael. Some years ago...',
    :copies_owned => 3
}
books_bucket = client.bucket('books')
new_book = books_bucket.new(book[:isbn])
new_book.data = book
new_book.data = book
new_book.store()


fetched_book = books_bucket.get(book[:isbn])
puts fetched_book.raw_data
par = JSON.parse(fetched_book.raw_data)
puts par["title"]

#puts fetched1.data
#fetched1.data == val1
#puts fetched2.data == val2
#puts fetched3.data.to_json == val3.to_json