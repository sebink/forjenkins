require 'nokogiri'
require 'open-uri'
require 'spreadsheet'
require 'open_uri_redirections'

@xcelarr=[]
@cat=[]

# Get a Nokogiri::HTML:Document for the page we’re interested in...
#https://itunes.apple.com/GB/app/bingo-games-by-888ladies-real/id736070946
#https://play.google.com/store/apps/details?id=com.sixtostart.zombiesrun

#@book = Spreadsheet.open("/Users/sebibbaby/Google Drive/QA/SQL Scripts/Exports/Application List.xls")
@book = Spreadsheet.open("applicationList.xls")
@sheet1 = @book.worksheet(0)
@sheet1[0,6] = "Maturity Level"
@sheet1[0,7] = "Category"

 @sheet1.each 1 do |row|
      break if row[0].nil? # if first cell empty
      @xcelarr<< row[2].to_s
end
#doc = Nokogiri::HTML(open('https://itunes.apple.com/jp/app/ru-hui-wu-liaono-chu-huiiapuriyyc/id510311083'))
 @xcelarr.each_with_index  do |url,index|
   puts url
   if url !=""
     if !(url.include? 'amzn') || ( url.include? 'amazon')
     begin
         doc = Nokogiri::HTML(open(url,:allow_redirections => :safe))
          puts url
         if (url.include? 'google') || (url .include? 'android')
          
           category = doc.css('.document-subtitle.category>span').text
           
           @sheet1[index+1,7] = category
           doc.css('.content').each do |link|
              if link.attribute('itemprop').to_s == "contentRating"
                @sheet1[index+1,6] = link.text
                puts link.text
              end
            end
          end
          if url.include? 'itunes'
            doc.css('.genre>a').each do |cat|
              @sheet1[index+1,7] = cat.text
            end
            doc.css('.app-rating').each do |link|
              @sheet1[index+1,6] = link.text
              puts link.text
             end
         end
       rescue OpenURI::HTTPError
      #redirect_to :back, notice: 'link's broken！'
    end
   end
  end
 end
  @sheet1.each_with_index 1 do |row,ind|
       break if row[0].nil?
  
        if(row[5] == row[7])
           row[8] = "Match"
       
        else
          row[8] = "MisMatch"
 end
 end
 @book.write 'maturity.xls'
