require 'nokogiri'
require 'open-uri'
require 'spreadsheet'


book = Spreadsheet.open('Motive_Camp_Status.xls')
@doc = Nokogiri::XML(open("http://motivefeed.com/affiliate/campaigns_v2?api_key=LstKht1GD0&affiliate_id=64104.xml"))
@sheet1 = book.worksheet(0)

@format = Spreadsheet::Format.new :color => :blue,
                                 :weight => :bold,
                                 :size => 12 
                                

@xmlString = @doc.inspect()

@coutryTargeting=[]
@devices=[]
@motiveCid=[]
@motiveofferid=""
@motiveCname= ""

      @sheet1[0,1] = 'Motive Campaign name'
      @sheet1[0,2] = 'Motive Offerid'
      @sheet1[0,3]= 'Motive Campaign id'
      @sheet1[0,4]='Country Targeting'
      @sheet1[0,5]='Devices'

def gettingTheValuesFromXml
  
  @doc.xpath('//campaign').each_with_index do |xml,ind|
      
        xml.xpath("allowed_countries/allowed_country").each do |t| 
        @coutryTargeting<<t.text.downcase
    end
      xml.xpath("allowed_devices/allowed_device").each do |d|
      @devices<<d.text
    end
      xml.xpath("campaign_id").each do |cid|
      @motiveCid=cid.text
    end
      xml.xpath("offer_id").each do |oid|
      @motiveofferid=oid.text
    end 
    xml.xpath("offer_name").each do |cname|
      @motiveCname = cname.text
   end
   
      @sheet1[ind+1,1] = @motiveCname
      @sheet1[ind+1,2] = @motiveofferid
      @sheet1[ind+1,3]= @motiveCid
      @sheet1[ind+1,4]=@coutryTargeting.join(",")  
      @sheet1[ind+1,5]=@devices.join(",")     
 

  @coutryTargeting.clear
    @devices.clear
    @motiveCname = ""
    @motiveCname = ""
    @motiveCname= ""
 
 end 
end



gettingTheValuesFromXml

book.write 'testingdata1.xls'
