=begin
require 'nokogiri'
require 'open-uri'
require 'mechanize'

www = Mechanize.new
www.get('http://publisher.altrooz.com/users/login') do |login_page|
    inside_page = login_page.form_with(:action => '/users/login') do |f|
      username_field = f.field_with(:name => "data[User][username]")
      username_field.value = "khurram@blutrumpet.com"
      password_field = f.field_with(:name => "data[User][password]")
      password_field.value = "khurramblutrumpet"
      #f.field_with(:type => "submit")
      f.submit
  end.click_button
end

doc = Nokogiri::HTML(open("http://publisher.altrooz.com/publisher/campaign_detail/8/77"))
    puts doc
    puts doc.xpath("html/body/div[2]/div/div[1]/dl/dd[2]").text
    
=end
=begin
require 'nokogiri'
require 'open-uri'
require 'zlib'
news_tmp_file = open('http://apps.blutrumpet.com/products/android/sample?debug&passthrough%5Bcountry_code%5D=de&passthrough%5Bc.useros%5D=7.0')
doc = Nokogiri::HTML(news_tmp_file)
arts = doc.xpath('//*[@id="main"]/ul/li')
arts.each do |art|
  puts art.text
end
=end

require 'rubygems'
require 'nokogiri'
require 'restclient'

page = Nokogiri::HTML(RestClient.get("http://apps.blutrumpet.com/products/android/sample?debug&passthrough%5Bcountry_code%5D=de&passthrough%5Bc.useros%5D=7.0"))   
puts page  # => Nokogiri::HTML::Document

