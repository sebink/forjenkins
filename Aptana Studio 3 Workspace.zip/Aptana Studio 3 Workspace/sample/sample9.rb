require 'nokogiri'
require 'open-uri'
require 'spreadsheet'


book = Spreadsheet.open('Motive_Camp_Status.xls')
@doc = Nokogiri::XML(open("http://motivefeed.com/affiliate/campaigns_v2?api_key=LstKht1GD0&affiliate_id=64104.xml"))
@sheet1 = book.worksheet(0)
@sheet2 = book.worksheet(1)
@xmlString = @doc.inspect()

@xlsarray=[]
@initilsXLS=[]
@NewCids=[]
@Countminus=0


def alldoing  
@sheet1.each 1 do |row|
  break if row[0].nil? # if first cell empty
  @xlsarray<< row[1].to_s
  
    if @xmlString.include? row[1].to_s
      
       row[8] = "Active"
        if(row[8] == row[6])
          row[9] = "Match"
     
        else
          row[9] = "MisMatch"
 
        end
    else
     row[8] = "Paused"
     if(row[6].to_s == (row[8].to_s||"Expired"))
     row[9] = "Match"
    end        
  end
end
end


def getsheet2Values
  
  @sheet2.each 1 do |row|
  break if row[0].nil? # if first cell empty
  @NewCids<< row[1].to_s
  
  end
  puts @NewCids.length
end


def searching
#puts @initilsXLS.length
   hash = Hash[@xlsarray.map.with_index.to_a] 
   @xlsarray.each_with_index do |values,index|
      
    if(@xmlString.scan(values).count>1)
      ind = hash[values]
       for j in 1..@xmlString.scan(values).count
          @initilsXLS.insert(@Countminus+1,["",values])
          @Countminus+=1
        end
       #puts @Countminus + index +1
    end
   end
end


def saveInitialSheet
  
  (1..@sheet1.row_count).each do |i| 
      @initilsXLS<< @sheet1.row(i)  # grab copies of the rows 
  end 
end



def writefile
  ##puts @initilsXLS[1]
  @initilsXLS.each_with_index do |item,index|
    @sheet2.insert_row(index+1, item) 
   
  end
   puts @sheet2.row_count
end
alldoing
saveInitialSheet
searching
writefile
getsheet2Values
book.write 'sample123.xls'
