require 'rubygems'
require "selenium-webdriver"
require "rspec"
require 'spreadsheet'
include RSpec::Expectations
require 'countries'


describe "AppiaCampAnalysis" do

  before(:all) do
    
    
    @driver = Selenium::WebDriver.for :firefox
    
    @driver.manage().window().maximize()

    @base_url = "https://via.appia.com/login.html"
    @accept_next_alert = true
    @driver.manage.timeouts.implicit_wait = 30
    @verification_errors = []
    @wait = Selenium::WebDriver::Wait.new(:timeout => 100)
    
    
    @book1 = Spreadsheet::Workbook.new
    #@book1.create_worksheet(:name => 'Appia')

    @dest_folder = File.dirname(__FILE__)
    @dateTime = ((Time.new).strftime("%Y-%m-%d %H.%M")).to_s
    @modifiedFile = "/Users/sebibbaby/Google Drive/QA/Automation Test Results/Campaigns by GEO/Appia #{@dateTime}.xls"
    @book = Spreadsheet.open('/Users/sebibbaby/Google Drive/QA/SQL Scripts/Exports/Appia_Camp_Status.xls')
    @sheet1 = @book.worksheet(0)
    @sheet2 = @book.worksheet(0)
   #@sheet2[0,0] = "Campaign Name"
   #@sheet2[0,1] = "Campaign Id"
   #@sheet2[0,2] = "Status"
   #@sheet2[0,3] = "Pay Out"
   #@sheet2[0,5] = "Min OS Version"
   #@sheet2[0,4] = "Geo"
   #@sheet2[0,6] = "PlatForm"
 
    @xcelarr = []
    @allActiveCamp = []
    @platform =[]
    @geo = []
 
  end
  
  after(:all) do
    @driver.quit
    #FileUtils.cp(@modifiedFile, @dest_folder)
  end


  it "Checking" do
    
    gettingDataFromXml
    
    #puts @xcelarr
    
    @driver.get(@base_url)
    @wait.until { @driver.find_element(:xpath => "//*[@id='emailAddress']").displayed? }
    @driver.find_element(:xpath, "//*[@id='emailAddress']").clear
    @driver.find_element(:xpath, "//*[@id='emailAddress']").click
    @driver.find_element(:xpath, "//*[@id='emailAddress']").send_keys "hsipe@breaktimestudios.com"
    
    @driver.find_element(:xpath, "//*[@id='password']").clear
    @driver.find_element(:xpath, "//*[@id='password']").click
    @driver.find_element(:xpath, "//*[@id='password']").send_keys "appia123"
    
    @driver.find_element(:xpath, "//*[@id='loginButton']").click
    @wait.until { @driver.find_element(:xpath => "html/body/nav/div[2]/ul[1]/li[1]/a").displayed? }
    
    @driver.get("https://via.appia.com/manualDashboard.html")
    
    @wait.until { @driver.find_element(:xpath => "//*[@id='filters']/div[2]/div/button").displayed? }
    
    repeatForActiveAndPending("Active")
    sleep 3
    #repeatForActiveAndPending("Pending")
    sleep 3
    
    gettingGeosAndPlatforms
    
    @book.write 'modifiedFile.xls'
  
  end  
    
 def repeatForActiveAndPending(stat)
      
    @driver.find_element(:xpath,"(//button[@type='button'])[4]").click
    sleep 2
    @driver.find_element(:link, stat).click
    sleep 5
    @driver.find_element(:xpath, "html/body/div[2]/div[1]/div/header/h1/span").click
    sleep 3
    
      #if(stat=="Active")
      # @wait.until { @driver.find_element(:xpath, "//*[@id='viewAll']").displayed? }
      # @driver.find_element(:xpath, "//*[@id='viewAll']").click
      # sleep 50
    #end

    gettingDataFromAPI
    
  end


   def gettingDataFromXml
  
      @sheet1.each 1 do |row|
      break if row[0].nil? # if first cell empty
      @xcelarr<< row[1].to_s
 
     end
  end
  
   def gettingDataFromAPI
    
    numberOfGames = @driver.find_elements(:xpath,"//*[@id='campaigns']/tbody/tr").size()
    puts numberOfGames
    if numberOfGames > 0
       for i in 1..numberOfGames
         
          status = @driver.find_element(:xpath, "//*[@id='campaigns']/tbody/tr[#{i}]/td[2]").text
          id = @driver.find_element(:xpath, "//*[@id='campaigns']/tbody/tr[#{i}]/td[3]").text
          name = @driver.find_element(:xpath, "//*[@id='campaigns']/tbody/tr[#{i}]/td[4]").text
          payout = (@driver.find_element(:xpath, "//*[@id='campaigns']/tbody/tr[#{i}]/td[6]").text)[1..5].to_f
       
        if gettingOutAlreadyExistingCamps(id) == true #&& payout >= 2.00
             
             #@sheet2[@sheet2.last_row_index+1,0] = name
           #  @sheet2[@sheet2.last_row_index,1] = id
             @sheet2[@sheet2.last_row_index,8] = status  
             @sheet2[@sheet2.last_row_index,9]=payout
             @allActiveCamp<<id
             
           end   
        end                       
     end
  end
    
    def gettingGeosAndPlatforms
      
         @allActiveCamp.each_with_index  do |id,index|
                 @driver.get("https://via.appia.com/campaign.html?campaignId=#{id}")
                 @wait.until{@driver.find_element(:xpath,"//*[@id='notification-switch']/div/label").displayed?}
                 #sleep 3
                 numberOfCountries = @driver.find_elements(:xpath,'//*[@id="countries"]/li').size() 
                    
                    for i in 1..numberOfCountries
                      cName = @driver.find_element(:xpath, "//*[@id='countries']/li[#{i}]").text
                      puts cName
                      if cName =="Great Britain (UK)"
                        cName = "United Kingdom"
                      end
                      if cName =="Croatia (Hrvatska)"
                        cName = "Croatia"
                      end
                      
                      c = Country.find_country_by_name(cName)
                      #puts c.alpha2
                      @platform<<c.alpha2
                      
                  end
                  if @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[5]/td[1]").text == "Min OS Version"
                     platform = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[5]/td[2]").text
                   else
                     platform = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[6]/td[2]").text
                  end                                        
                  
                  if @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[2]/td[2]").text =="iOS"
                    get(index)
                  else
                     @sheet2[index+1,11] = "Android"
                  end
                   #puts platform
                   @sheet2[index+1,10] = @platform.join(',')
                   @sheet2[index+1,11] = platform
                   
                   @platform.clear
                   @geo.clear
          end
          
   end
   
   def get(index)
     puts @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[1]").text
     if @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[1]").text == "Excluded Devices"
         numberOfDevices = @driver.find_elements(:xpath,'html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[2]/ul').size() 
         puts numberOfDevices
          for i in 1..numberOfDevices
                      pName = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[2]/ul/li[#{i}]").text
                      @geo<<pName
                      
                   end
                   else
                    
                     numberOfDevices = @driver.find_elements(:xpath,'html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[9]/td[2]/ul').size() 
                      puts numberOfDevices
                     for i in 1..numberOfDevices
                      pName = @driver.find_element(:xpath, "html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[9]/td[2]/ul/li[#{i}]").text
                      @geo<<pName  
                    end
                  end 
                  if @geo.include? 'Apple iPhone'
                    @sheet2[index+1,12] = "iPad" 
                   end
                   if @geo.include? 'Apple iPad' 
                     @sheet2[index+1,12] = "iPhone"
                   end
                  if @sheet2[index+1,12].nil?
                    @sheet2[index+1,12] = "iPhone,iPad"
                  end
                  
            end
   
    def gettingOutAlreadyExistingCamps(link)
  
      return true if @xcelarr.include? link
      false   
    end   

    def element_present?(how, what)
      
      @driver.find_element(how, what)
      true
      
      rescue Selenium::WebDriver::Error::NoSuchElementError
      false
      
    end
  
   def alert_present?()
      
      @driver.switch_to.alert
      true
      rescue Selenium::WebDriver::Error::NoAlertPresentError
      false
      
    end
  
   def verify(&blk)
      yield
      rescue ExpectationNotMetError => ex
      @verification_errors << ex
      
    end
  
   def close_alert_and_get_its_text(how, what)
      alert = @driver.switch_to().alert()
      alert_text = alert.text
      if (@accept_next_alert) then
        alert.accept()
      else
        alert.dismiss()
      end
      alert_text
    ensure
      @accept_next_alert = true
  end
end
