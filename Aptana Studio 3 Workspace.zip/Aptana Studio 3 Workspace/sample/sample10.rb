require 'rubygems'
require "rspec"
require 'spreadsheet'
include RSpec::Expectations

describe "hjsbfsdfksdfb" do

  before(:all) do

    @dest_folder = File.dirname(__FILE__)
    dateTime = ((Time.now - (240 * 60 + 0)).strftime("%Y-%b-%d %H.%M")).to_s
    
    #@modifiedFile = "/Users/sebibbaby/Google Drive/QA/Automation Test Results/Partner Campaign Analysis/Appia/Appia #{dateTime}.xls"
    @format = Spreadsheet::Format.new :color=> :blue, :pattern_fg_color => :yellow, :pattern => 1,:bold=>true,:border_color=>:red
    @book3 = Spreadsheet.open('/Users/sebibbaby/Google Drive/QA/Automation Test Results/Partner Campaign Analysis/Altrooz/Last_file/fsdfd.xls')
    @book4 = Spreadsheet.open('fsdfd2.xls')
    @book5 = Spreadsheet::Workbook.new
    
    @data = Array.new
    @data1= Array.new
    @mismatch = Array.new
    
    @sheet3 = @book3.worksheet(0)
    @sheet4 = @book4.worksheet(0) 
    @sheet5 = @book5.create_worksheet(:name => 'Altrooz')
   
   end
   it 'sdsd' do
     
    (1..@sheet3.row_count).each do |i| 
      @data.push @sheet3.row(i)  # grab copies of the rows 
    end
    (1..@sheet4.row_count).each do |i| 
      @data1.push @sheet4.row(i)  # grab copies of the rows 
    end
      print_elements_not_in_array
      putmismatchdataback
      @book5.write "altrooz.xls"
   end
   
  def print_elements_not_in_array
    @data.each_with_index do |temp,ind|
          
           if temp != @data1[ind]
              @mismatch<<@data1[ind]
              puts @mismatch.length
            end
        end
    end
    
    def putmismatchdataback 
      @data1.each_with_index do |item,index|
        @sheet5.insert_row(@sheet5.last_row_index+1, item) 
        if @mismatch.include? item
          puts 6
          @sheet5.row(index+1).set_format(0,@format)
          @sheet5.row(index+1).set_format(1,@format)
          @sheet5.row(index+1).set_format(2,@format)          
          #row1 = @sheet5.row(index)
          #row1.set_format(index, @format)
        end
    end
     puts  @sheet3.last_row_index
   puts @sheet4.last_row_index
   puts @sheet5.last_row_index
  end
end