require 'nokogiri'
require 'open-uri'
require 'spreadsheet'

@NewCids=[]
book = Spreadsheet.open('Motive_Camp_Status.xls')
@sheet1 = book.worksheet(0)
@doc = Nokogiri::XML(open("http://motivefeed.com/affiliate/campaigns_v2?api_key=LstKht1GD0&affiliate_id=64104.xml"))
str1 = @doc.inspect()

@count=0

def getsheet2Values
  
  @sheet1.each 1 do |row|
  break if row[1].nil? # if first cell empty
  @NewCids<< row[1].to_s
  
  end
  puts @NewCids.length
end
getsheet2Values
  @NewCids.each_with_index do |value,index|
      @doc.xpath("//campaign").each do |xml| 
          
        if xml.to_s.include? value.to_s
          name = xml.xpath("campaign_id").text
          puts value.to_s + " "+ name.to_s + " "+ @count.to_s
          @count+=1
        end
      
  end

end
book.write 'test44444.xls'
 #puts @doc.to_enum(:scan, 'http://traktum.com/?a=64104&c=303273&s1=').inject(0) {|s,| s+1}