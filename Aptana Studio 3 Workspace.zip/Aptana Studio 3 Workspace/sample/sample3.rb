require 'rubygems'
require "selenium-webdriver"
require "rspec"
require 'spreadsheet'
include RSpec::Expectations
require 'countries'

describe "AppiaCampAnalysis" do

  before(:all) do
    
    
    @driver = Selenium::WebDriver.for :firefox
    
    @driver.manage().window().maximize()

    @base_url = "https://via.appia.com/login.html"
    @accept_next_alert = true
    @driver.manage.timeouts.implicit_wait = 30
    @verification_errors = []
    @wait = Selenium::WebDriver::Wait.new(:timeout => 100)
    
    
    #@book1 = Spreadsheet::Workbook.new
    #@book1.create_worksheet(:name => 'Appia')

     @dest_folder = File.dirname(__FILE__)
    @dateTime = ((Time.new).strftime("%Y-%m-%d %H.%M")).to_s
    @modifiedFile = "/Users/sebibbaby/Google Drive/QA/Automation Test Results/Partner Campaign Analysis/Appia/#{@dateTime}.xls"
    @modifiedFile1 = "/Users/sebibbaby/Google Drive/QA/Automation Test Results/Partner Campaign Analysis/Appia/appia.xls"
    @book = Spreadsheet.open('/Users/sebibbaby/Google Drive/QA/SQL Scripts/Exports/Appia_Camp_Status.xls')
    @sheet1 = @book.worksheet(0)
    
   @sheet1[0,8] = "Appia Status"
   @sheet1[0,10] = "Appia Payout"
   @sheet1[0,12] = "Appia Geo"
   @sheet1[0,16] = "Appia Platform"
   @sheet1[0,17] = "Appia Id"
   
 
    @xcelarr = []
    @allActiveCamp = []
    @platform =[]
    @geo = []
 
  end
  
  after(:all) do
    @driver.quit
    #FileUtils.cp(@modifiedFile, @dest_folder)
  end

   def gettingDataFromExcel
  
      @sheet1.each 1 do |row|
      break if row[0].nil? # if first cell empty
      @xcelarr<< row[1].to_s
 
     end
  end
  
  it "Checking" do
  #  gettingDataFromExcel
    
    @driver.get(@base_url)
    @wait.until { @driver.find_element(:xpath => "//*[@id='emailAddress']").displayed? }
    @driver.find_element(:xpath, "//*[@id='emailAddress']").clear
    @driver.find_element(:xpath, "//*[@id='emailAddress']").click
    @driver.find_element(:xpath, "//*[@id='emailAddress']").send_keys "hsipe@breaktimestudios.com"
    
    @driver.find_element(:xpath, "//*[@id='password']").clear
    @driver.find_element(:xpath, "//*[@id='password']").click
    @driver.find_element(:xpath, "//*[@id='password']").send_keys "appia123"
    
    @driver.find_element(:xpath, "//*[@id='loginButton']").click
    @wait.until { @driver.find_element(:xpath => "html/body/nav/div[2]/ul[1]/li[1]/a").displayed? }
    
    #@driver.get("https://via.appia.com/manualDashboard.html")
    
    #wait.until { @driver.find_element(:xpath => "//*[@id='filters']/div[2]/div/button").displayed? }
    
    @driver.get("https://via.appia.com/campaign.html?campaignId=2795")
   @wait.until{@driver.find_element(:xpath,"//*[@id='notification-switch']/div/label").displayed?}
   
   numberOfDevices = @driver.find_elements(:xpath,'html/body/div[2]/div[2]/div[2]/div/div[2]/table/tbody/tr[8]/td[2]/ul/li').size() 
         puts "8 devices" + numberOfDevices.to_s
         
  end
end