#=begin
require 'rubygems'
require "selenium-webdriver"
require "rspec"
require 'spreadsheet'
require 'open-uri'

s1 = "/Users/sebibbaby/Google Drive/QA/Automation Test Results/Partner Campaign Analysis/Motive/Motive 2014-May-14 16.41.xls" 
s2 = "/Users/sebibbaby/Google Drive/QA/Automation Test Results/Partner Campaign Analysis/Motive/Motive 2014-May-14 10.42.xls"




tokens = [["hello", "world"], ["good", "lord"], ["hello", "lord"]]

tokens_hash = Hash.new{|h, k| h[k] = []}

tokens.each_with_index do |subarr, i|
  subarr.each do |word|
    tokens_hash[word] << i
  end
#  puts tokens_hash
end

