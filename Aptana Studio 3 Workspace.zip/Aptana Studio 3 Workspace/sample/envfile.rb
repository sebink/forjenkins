str = "$2.00"
if (puts str[1..5].to_f >= 2.00)

end
