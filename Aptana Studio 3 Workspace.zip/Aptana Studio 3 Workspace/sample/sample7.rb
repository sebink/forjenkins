require 'nokogiri'
require 'open-uri'
require 'spreadsheet'
@xlsarray=[]
@xmlarr=[]
@Duplicates=[]
@coutryTargeting=[]
@devices = []
@motiveCid= []
@motiveofferid=[]
@initilsXLS=[]
@NewCids=[]
@Countminus=0
@Counter=1
@count=0
book = Spreadsheet.open('Motive_Camp_Status.xls')
@doc = Nokogiri::XML(open("http://motivefeed.com/affiliate/campaigns_v2?api_key=LstKht1GD0&affiliate_id=64104.xml"))
@sheet1 = book.worksheet(0)
@sheet2 = book.worksheet(1)
@xmlString = @doc.inspect()

#@sheet1[0,8] = "Motive Status"
#@sheet1[0,11] = "Motive Country Status"
#@sheet1[0,14] = "Motive Platform Status"
#@sheet1[0,16] = "Motive Campaign Id"
#@sheet1[0,17] = "Motive Offer Id"

@sheet2[0,3] = "Motive Offer Id"

def saveInitialSheet
  
  (1..@sheet1.row_count).each do |i| 
      @initilsXLS<< @sheet1.row(i).dup  # grab copies of the rows 
  end 
end



def alldoing  
@sheet1.each 1 do |row|
  break if row[0].nil? # if first cell empty
  @xlsarray<< row[1].to_s
  
    if @xmlString.include? row[1].to_s
      
       row[8] = "Active"
        if(row[8] == row[6])
          row[9] = "Match"
     
        else
          row[9] = "MisMatch"
 
        end
    else
     row[8] = "Paused"
     if(row[6].to_s == (row[8].to_s||"Expired"))
     row[9] = "Match"
    end        
  end
end
end


def searching
    
  #@xlsarray1 = @xlsarray.uniq
  hash = Hash[@xlsarray.map.with_index.to_a] 
   @xlsarray.each_with_index do |values,index|
      
    if(@xmlString.scan(values).count>1)
      ind = hash[values]
       for j in 1..@xmlString.scan(values).count
          @initilsXLS.insert(@Countminus+index+1,["",values])
          @Countminus+=1
        end
       #puts @Countminus + index +1
    end
   end
end

def writefile
  ##puts @initilsXLS[1]
  @initilsXLS.each_with_index do |item,index|
    @sheet2.insert_row(index+1, item) 
   
  end
   puts @sheet2.row_count
end

def puttingValuesForGeos
#puts @NewCids.length
  getsheet2Values
  puts @NewCids.length
  @NewCids.each_with_index do |value,index|
   # @value = value
      @doc.xpath("//campaign").each do |xml| 
          
        if xml.to_s.include? value.to_s
          name = xml.xpath("campaign_id").text
          #puts value.to_s + " "+ name.to_s + " "+ @count.to_s
          @count+=1
          @sheet2.each 1 do |row|
          break if row[0].nil?
           
                puts row[1].to_s + " " + value
                #puts row[16].length
            if row[1].to_s == value.to_s
              puts 1
            @sheet2[@count,16]=name
        end
     end
  end
end
end
  
end
def CompareValue(val1,val2,from)
    
    if(from == "country")
        val1.casecmp val2
    else
      if(val2 =="") 
        ##puts(val1 + "empty")
        return 1
      else(val2.include? val1)
    end
      return 0
    end
  end     
 

def getsheet2Values
  
  @sheet2.each 1 do |row|
  break if row[0].nil? # if first cell empty
  @NewCids<< row[1].to_s
  
  end
end

alldoing
saveInitialSheet
searching
writefile
puttingValuesForGeos
#addvalues
book.write 'test777.xls'
