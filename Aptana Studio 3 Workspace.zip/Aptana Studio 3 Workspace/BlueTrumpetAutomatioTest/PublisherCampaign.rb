require 'json'
require 'selenium-webdriver'
require "rspec"
include RSpec::Expectations

describe 'My behaviour' do

  #Int test
  before(:all) do

    if(@driver == nil)

      @driver = Selenium::WebDriver.for :firefox

    end

    @driver.manage().window().maximize()
    @base_url = 'http://uat-portal.blutrumpet.com/'
    @accept_next_alert = true
    @driver.manage.timeouts.implicit_wait = 30
    @verification_errors = []
    @Appname = AppName+"Editted"
    CampaignName = "Publisher Camp ".concat(Array.new(10){rand(10).to_s(10)}.join)
    AppwallName = Array.new(10){rand(10).to_s(10)}.joins


  end

  # do these steps before all
  after(:all) do

    @verification_errors.should == []
    @driver.find_element(:xpath,"//*[@id='pgWrap']/div[1]/div[2]/img").click
    @driver.find_element(:xpath,"//*[@id='pgWrap']/div[1]/div[2]/div/div[5]").click
    sleep 5

    verify { (@driver.find_element(:xpath, "//*[@id='topBar']/div/div[1]/ul[2]/li[3]/a").text).should == "SIGN UP" }
    verify { (@driver.find_element(:xpath, "//*[@id='topBar']/div/div[1]/ul[2]/li[4]/a").text).should == "LOG IN" }
    @driver.quit

  end

  #login into the system before doing anything.
  it "test_Init_login" do


    @driver.get(@base_url + '/b/site/index.html')
    @driver.find_element(:link, 'LOG IN').click
    @driver.find_element(:name, 'client[email]').clear
    @driver.find_element(:name, 'client[email]').send_keys 'sebin@blutrumpet.com'
    @driver.find_element(:name, 'client[password]').click
    @driver.find_element(:name, 'client[password]').clear
    @driver.find_element(:name, 'client[password]').send_keys 'jan@2014'
    @driver.find_element(:xpath, "(//input[@value='SUBMIT'])[2]").click
    #debugger
    !60.times{ break if (element_present?(:id, 'userName') rescue false); sleep 1 }
    sleep 10

    verify { (@driver.find_element(:id, 'userName').text).should == 'Sebin Baby'}
    verify { (@driver.title).should == 'BluTrumpet Admin'}
    verify { (@driver.find_element(:css, 'button.drkGrey').text).should == "FILTER" }
    verify { (@driver.find_element(:css, 'div.chartHdr').text).should == "Application Earn" }
    verify { (@driver.find_element(:css, 'div.chartCell.right > div.chartHdr').text).should == "Campaign Spend" }
    verify { (@driver.find_element(:xpath, "//div[@id='pgWrap']/div[3]/div[5]/div").text).should == "Campaign Installs" }
    verify { (@driver.find_element(:xpath, "//div[@id='pgWrap']/div[3]/div[4]/div").text).should == "Campaign Impressions" }

  end

  #Create Campaign
  it "test_create_advertise_campign" do

    @driver.get(@base_url + "/b/publisher_campaign.html")
    sleep 3
    @driver.find_element(:id, "campaignName").clear
    @driver.find_element(:id, "campaignName").send_keys CampaignName
    sleep 10

    Selenium::WebDriver::Support::Select.new(@driver.find_element(:xpath ,"//*[@id='appName']")).select_by(:text, @Appname)
    #@driver.find_element(:css, "option[value=\"1749410162\"]").click

    time = Date.today+1
    formatedDate = time.strftime("%Y-%m-%d")

    @driver.find_element(:name,"startDate").clear
    @driver.find_element(:name, "startDate").send_key formatedDate

    sleep 3
    @driver.find_element(:xpath, "//*[@id='undefined-sticky-wrapper']/div/div[2]").click
    sleep 2

    @driver.find_element(:id, "appWallTitle").clear
    @driver.find_element(:id, "appWallTitle").send_keys AppwallName

    sleep 3
    @driver.find_element(:xpath ,"//*[@id='appWallTheme']").click
    @driver.find_element(:xpath ,"//*[@id='appWallTheme']").find_elements( :tag_name => "option" ).find do |option|
      option.text == "Theme 7"
    end.click
    sleep 10

    @driver.find_element(:css, "button.greenLarge.submitForm").click
    sleep 20

    @driver.find_element(:xpath, "//*[@id='filterApps']").click
    @driver.find_element(:xpath, "//*[@id='filterApps']").send_keys CampaignName, :enter
    sleep 5

    (@driver.find_element(:link, CampaignName).text).should == CampaignName

  end


  it "test_edit_advertisercamp" do

    puts("Edit Publisher camp")


    sleep 3
    @driver.find_element(:link, CampaignName).click
    sleep 10
    !60.times{ break if (element_present?(:id, "campaignName") rescue false); sleep 1 }
    @driver.find_element(:id, "campaignName").clear
    CampNameEditted = CampaignName.concat(" Editted")

    @driver.find_element(:id, "campaignName").send_keys CampNameEditted

    time = Date.today+2
    formatedDate = time.strftime("%Y-%m-%d")

    @driver.find_element(:name,"startDate").clear
    @driver.find_element(:name, "startDate").send_key formatedDate

    sleep 3
    @driver.find_element(:xpath, "//*[@id='undefined-sticky-wrapper']/div/div[2]").click
    sleep 2

    @driver.find_element(:id, "appWallTitle").clear
    @driver.find_element(:id, "appWallTitle").send_keys AppwallName.concat(" Editted")

    sleep 3
    @driver.find_element(:xpath ,"//*[@id='appWallTheme']").click
    @driver.find_element(:xpath ,"//*[@id='appWallTheme']").find_elements( :tag_name => "option" ).find do |option|
      option.text == "Theme 3"
    end.click
    sleep 10

    @driver.find_element(:css, "button.greenLarge.submitForm").click
    sleep 20

    @driver.find_element(:xpath, "//*[@id='filterApps']").click
    @driver.find_element(:xpath, "//*[@id='filterApps']").send_keys CampNameEditted, :enter
    sleep 5

    (@driver.find_element(:link, CampNameEditted).text).should == CampNameEditted
    @driver.find_element(:link, CampNameEditted).click

    sleep 10
    verify { (@driver.find_element(:id, "campaignName").text).should == CampNameEditted }
    verify { (@driver.find_element(:name, "startDate").text).should == formatedDate }

    @driver.find_element(:xpath, "//*[@id='undefined-sticky-wrapper']/div/div[2]").click
    sleep 2

    verify { (@driver.find_element(:id, "appWallTitle").text).should == AppwallName.concat(" Editted") }

    @driver.find_element(:xpath, "//*[@id='pgWrap']/div[3]/div[3]/button[1]").click
    sleep 10


  end

  it 'should_Delete_PublisherCampaign ' do

    @driver.find_element(:xpath, "//*[@id='filterApps']").click
    @driver.find_element(:xpath, "//*[@id='filterApps']").send_keys CampNameEditted, :enter
    sleep 5

    @driver.find_element(:xpath, "(//img[@title='delete'])[1]").click
    @driver.switch_to.alert.accept

    sleep 5

    @driver.find_element(:xpath, "//*[@id='filterApps']").click
    @driver.find_element(:xpath, "//*[@id='filterApps']").send_keys CampNameEditted, :enter
    sleep 5

  end


  def element_present?(how, what)

    @driver.find_element(how, what)
    true
  rescue Selenium::WebDriver::Error::NoSuchElementError
    false
  end

  def alert_present?()

    @driver.switch_to.alert
    true
  rescue Selenium::WebDriver::Error::NoAlertPresentError
    false
  end

  def verify(&blk)

    yield
  rescue ExpectationNotMetError => ex
    @verification_errors << ex
  end

  def close_alert_and_get_its_text(how, what)

    alert = @driver.switch_to().alert()
    alert_text = alert.text
    if (@accept_next_alert) then
      alert.accept()
    else
      alert.dismiss()
    end
    alert_text
  ensure
    @accept_next_alert = true

  end
end