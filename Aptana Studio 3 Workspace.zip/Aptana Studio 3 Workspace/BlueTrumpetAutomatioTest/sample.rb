require "json"
require "selenium-webdriver"
require "rspec"
#require 'debugger'
include RSpec::Expectations

describe "Tttttttttt" do

  before(:each) do
    @driver = Selenium::WebDriver.for :firefox
    @driver.manage().window().maximize()
    @base_url = "http://uat-portal.blutrumpet.com/"
    @accept_next_alert = true
    @driver.manage.timeouts.implicit_wait = 30
    @verification_errors = []
  end

  after(:each) do
    @driver.quit
    #@verification_errors.should == []
  end

  it "test_tttttttttt" do

    login
    sleep 5
    @driver.navigate.to("http://uat-portal.blutrumpet.com/b/app.html?id=511")


    result = checking_the_dropdown_Value("category")
    result.should == "News"


    #@driver.get(@base_url + "/b/app.html")
    #Selenium::WebDriver::Support::Select.new(@driver.find_element(:id, "category")).select_by(:text, "Sports")
    #@driver.find_element(:css, "option[value=\"19\"]").click
    #Selenium::WebDriver::Support::Select.new(@driver.find_element(:id, "category")).select_by(:text, "Photography")
    #@driver.find_element(:css, "option[value=\"13\"]").click
    #puts(@driver.find_element(:css,"customSelectInner").text)
    #AppName = rand(8).to_s.concat(".jpg")

    sleep 3
    #puts(AppName)

   file = filepath("assets/".concat(rand(8).to_s.concat(".jpg")))
 #   puts(file)
  end

  def checking_the_dropdown_Value(id)

  dropdown = @driver.find_element(id: id)
  select_list = Selenium::WebDriver::Support::Select.new(dropdown)
  puts(select_list.selected_options[0].text)
  return select_list.selected_options[0].text

  end


    def login
      @driver.get(@base_url + '/b/site/index.html')
      @driver.find_element(:link, 'LOG IN').click
      @driver.find_element(:name, 'client[email]').clear
      @driver.find_element(:name, 'client[email]').send_keys 'sebin@blutrumpet.com'
      @driver.find_element(:name, 'client[password]').click
      @driver.find_element(:name, 'client[password]').clear
      @driver.find_element(:name, 'client[password]').send_keys 'jan@2014'
      @driver.find_element(:xpath, "(//input[@value='SUBMIT'])[2]").click
      #debugger
    end
  def filepath filename

    File.expand_path(File.join(File.dirname(__FILE__), filename))

  end

  def element_present?(how, what)
    @driver.find_element(how, what)
    true
  rescue Selenium::WebDriver::Error::NoSuchElementError
    false
  end

  def alert_present?()
    @driver.switch_to.alert
    true
  rescue Selenium::WebDriver::Error::NoAlertPresentError
    false
  end

  def verify(&blk)
    yield
  rescue ExpectationNotMetError => ex
    @verification_errors << ex
  end

  def close_alert_and_get_its_text(how, what)
    alert =@driver.switch_to().alert()
    alert_text = alert.text
    if (@accept_next_alert) then
      alert.accept()
    else
      alert.dismiss()
    end
    alert_text
  ensure
    @accept_next_alert = true
  end
end
