module GC


  def self.disable
  end

  def self.enable
  end

  def self.start
  end

  def self.stress
  end

  def self.stress=(arg0)
  end


  def garbage_collect
  end


  protected


  private

end
