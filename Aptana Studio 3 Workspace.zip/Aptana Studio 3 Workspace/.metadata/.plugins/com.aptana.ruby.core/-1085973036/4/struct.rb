class Struct < Object
  include Enumerable

  Enumerator = Enumerable::Enumerator
  Group = Struct::Group
  Passwd = Struct::Passwd
  Tms = Struct::Tms

  def self.new(arg0, arg1, *rest)
  end


  def ==
  end

  def []
  end

  def []=
  end

  def each
  end

  def each_pair
  end

  def eql?
  end

  def hash
  end

  def inspect
  end

  def length
  end

  def members
  end

  def select
  end

  def size
  end

  def to_a
  end

  def to_s
  end

  def values
  end

  def values_at
  end


  protected


  private

  def initialize
  end

  def initialize_copy
  end

end
