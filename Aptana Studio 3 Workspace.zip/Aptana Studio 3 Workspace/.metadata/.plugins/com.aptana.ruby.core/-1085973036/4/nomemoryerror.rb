class NoMemoryError < Exception




  protected


  private

end
