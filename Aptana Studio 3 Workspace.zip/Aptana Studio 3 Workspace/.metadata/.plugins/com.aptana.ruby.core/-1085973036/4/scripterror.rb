class ScriptError < Exception




  protected


  private

end
