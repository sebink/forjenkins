class Proc < Object


  def self.new(arg0, arg1, *rest)
  end


  def ==
  end

  def []
  end

  def arity
  end

  def binding
  end

  def call
  end

  def clone
  end

  def dup
  end

  def to_proc
  end

  def to_s
  end


  protected


  private

end
