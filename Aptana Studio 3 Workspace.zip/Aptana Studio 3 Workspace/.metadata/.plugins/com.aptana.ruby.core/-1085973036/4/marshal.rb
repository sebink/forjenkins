module Marshal

  MAJOR_VERSION = 4
  MINOR_VERSION = 8

  def self.dump(arg0, arg1, *rest)
  end

  def self.load(arg0, arg1, *rest)
  end

  def self.restore(arg0, arg1, *rest)
  end



  protected


  private

  def dump(arg0, arg1, *rest)
  end

  def load(arg0, arg1, *rest)
  end

  def restore(arg0, arg1, *rest)
  end

end
