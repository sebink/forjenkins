class StopIteration < IndexError




  protected


  private

end
