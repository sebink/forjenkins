class Range < Object
  include Enumerable

  Enumerator = Enumerable::Enumerator


  def ==
  end

  def ===
  end

  def begin
  end

  def each
  end

  def end
  end

  def eql?
  end

  def exclude_end?
  end

  def first
  end

  def hash
  end

  def include?
  end

  def inspect
  end

  def last
  end

  def member?
  end

  def step
  end

  def to_s
  end


  protected


  private

  def initialize
  end

end
