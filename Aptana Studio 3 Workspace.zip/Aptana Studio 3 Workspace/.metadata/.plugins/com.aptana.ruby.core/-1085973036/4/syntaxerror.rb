class SyntaxError < ScriptError




  protected


  private

end
