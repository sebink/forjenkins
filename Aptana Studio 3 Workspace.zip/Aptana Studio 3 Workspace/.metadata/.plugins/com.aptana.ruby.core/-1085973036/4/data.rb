class Data < Object




  protected


  private

end
