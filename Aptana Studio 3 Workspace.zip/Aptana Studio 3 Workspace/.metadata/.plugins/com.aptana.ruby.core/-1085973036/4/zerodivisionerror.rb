class ZeroDivisionError < StandardError




  protected


  private

end
