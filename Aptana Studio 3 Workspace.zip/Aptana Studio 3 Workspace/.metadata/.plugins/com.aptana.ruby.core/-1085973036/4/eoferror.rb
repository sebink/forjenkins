class EOFError < IOError




  protected


  private

end
