class SystemStackError < StandardError




  protected


  private

end
