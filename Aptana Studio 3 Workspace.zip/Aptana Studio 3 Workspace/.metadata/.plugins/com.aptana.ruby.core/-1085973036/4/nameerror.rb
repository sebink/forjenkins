class NameError < StandardError



  def name
  end

  def to_s
  end


  protected


  private

  def initialize(arg0, arg1, *rest)
  end

end
