class Regexp < Object

  EXTENDED = 2
  IGNORECASE = 1
  MULTILINE = 4

  def self.compile(arg0, arg1, *rest)
  end

  def self.escape(arg0, arg1, *rest)
  end

  def self.last_match(arg0, arg1, *rest)
  end

  def self.quote(arg0, arg1, *rest)
  end

  def self.union(arg0, arg1, *rest)
  end


  def ==
  end

  def ===
  end

  def =~
  end

  def casefold?
  end

  def eql?
  end

  def hash
  end

  def inspect
  end

  def kcode
  end

  def match
  end

  def options
  end

  def source
  end

  def to_s
  end

  def ~
  end


  protected


  private

  def initialize
  end

  def initialize_copy
  end

end
