module Comparable



  def <(arg0)
  end

  def <=(arg0)
  end

  def ==(arg0)
  end

  def >(arg0)
  end

  def >=(arg0)
  end

  def between?(arg0, arg1)
  end


  protected


  private

end
