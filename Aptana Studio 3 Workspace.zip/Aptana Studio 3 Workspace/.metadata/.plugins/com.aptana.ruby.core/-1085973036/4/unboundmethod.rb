class UnboundMethod < Object



  def ==
  end

  def arity
  end

  def bind
  end

  def clone
  end

  def inspect
  end

  def name
  end

  def owner
  end

  def to_s
  end


  protected


  private

end
