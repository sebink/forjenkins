module FileTest


  def self.blockdev?(arg0)
  end

  def self.chardev?(arg0)
  end

  def self.directory?(arg0)
  end

  def self.executable?(arg0)
  end

  def self.executable_real?(arg0)
  end

  def self.exist?(arg0)
  end

  def self.exists?(arg0)
  end

  def self.file?(arg0)
  end

  def self.grpowned?(arg0)
  end

  def self.identical?(arg0, arg1)
  end

  def self.owned?(arg0)
  end

  def self.pipe?(arg0)
  end

  def self.readable?(arg0)
  end

  def self.readable_real?(arg0)
  end

  def self.setgid?(arg0)
  end

  def self.setuid?(arg0)
  end

  def self.size(arg0)
  end

  def self.size?(arg0)
  end

  def self.socket?(arg0)
  end

  def self.sticky?(arg0)
  end

  def self.symlink?(arg0)
  end

  def self.writable?(arg0)
  end

  def self.writable_real?(arg0)
  end

  def self.zero?(arg0)
  end



  protected


  private

  def blockdev?(arg0)
  end

  def chardev?(arg0)
  end

  def directory?(arg0)
  end

  def executable?(arg0)
  end

  def executable_real?(arg0)
  end

  def exist?(arg0)
  end

  def exists?(arg0)
  end

  def file?(arg0)
  end

  def grpowned?(arg0)
  end

  def identical?(arg0, arg1)
  end

  def owned?(arg0)
  end

  def pipe?(arg0)
  end

  def readable?(arg0)
  end

  def readable_real?(arg0)
  end

  def setgid?(arg0)
  end

  def setuid?(arg0)
  end

  def size(arg0)
  end

  def size?(arg0)
  end

  def socket?(arg0)
  end

  def sticky?(arg0)
  end

  def symlink?(arg0)
  end

  def writable?(arg0)
  end

  def writable_real?(arg0)
  end

  def zero?(arg0)
  end

end
