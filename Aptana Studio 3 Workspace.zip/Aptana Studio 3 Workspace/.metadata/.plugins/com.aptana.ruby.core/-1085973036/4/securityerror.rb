class SecurityError < StandardError




  protected


  private

end
