class RegexpError < StandardError




  protected


  private

end
