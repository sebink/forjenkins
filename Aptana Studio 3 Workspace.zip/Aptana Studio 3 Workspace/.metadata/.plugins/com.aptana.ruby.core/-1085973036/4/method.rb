class Method < Object



  def ==
  end

  def []
  end

  def arity
  end

  def call
  end

  def clone
  end

  def inspect
  end

  def name
  end

  def owner
  end

  def receiver
  end

  def to_proc
  end

  def to_s
  end

  def unbind
  end


  protected


  private

end
