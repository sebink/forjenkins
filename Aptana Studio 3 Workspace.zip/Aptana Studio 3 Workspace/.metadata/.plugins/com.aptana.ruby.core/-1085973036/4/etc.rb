module Etc


  def self.endgrent
  end

  def self.endpwent
  end

  def self.getgrent
  end

  def self.getgrgid(arg0)
  end

  def self.getgrnam(arg0)
  end

  def self.getlogin
  end

  def self.getpwent
  end

  def self.getpwnam(arg0)
  end

  def self.getpwuid(arg0, arg1, *rest)
  end

  def self.group
  end

  def self.passwd
  end

  def self.setgrent
  end

  def self.setpwent
  end



  protected


  private

  def endgrent
  end

  def endpwent
  end

  def getgrent
  end

  def getgrgid(arg0)
  end

  def getgrnam(arg0)
  end

  def getlogin
  end

  def getpwent
  end

  def getpwnam(arg0)
  end

  def getpwuid(arg0, arg1, *rest)
  end

  def group
  end

  def passwd
  end

  def setgrent
  end

  def setpwent
  end

end
