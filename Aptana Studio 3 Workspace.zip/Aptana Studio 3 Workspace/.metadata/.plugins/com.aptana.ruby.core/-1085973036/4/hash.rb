class Hash < Object
  include Enumerable

  Enumerator = Enumerable::Enumerator

  def self.[](arg0, arg1, *rest)
  end


  def ==(arg0)
  end

  def [](arg0)
  end

  def []=(arg0, arg1)
  end

  def clear
  end

  def default(arg0, arg1, *rest)
  end

  def default=(arg0)
  end

  def default_proc
  end

  def delete(arg0)
  end

  def delete_if
  end

  def each
  end

  def each_key
  end

  def each_pair
  end

  def each_value
  end

  def empty?
  end

  def eql?(arg0)
  end

  def fetch(arg0, arg1, *rest)
  end

  def has_key?(arg0)
  end

  def has_value?(arg0)
  end

  def hash
  end

  def include?(arg0)
  end

  def index(arg0)
  end

  def indexes(arg0, arg1, *rest)
  end

  def indices(arg0, arg1, *rest)
  end

  def inspect
  end

  def invert
  end

  def key?(arg0)
  end

  def keys
  end

  def length
  end

  def member?(arg0)
  end

  def merge(arg0)
  end

  def merge!(arg0)
  end

  def rehash
  end

  def reject
  end

  def reject!
  end

  def replace(arg0)
  end

  def select
  end

  def shift
  end

  def size
  end

  def sort
  end

  def store(arg0, arg1)
  end

  def to_a
  end

  def to_hash
  end

  def to_s
  end

  def update(arg0)
  end

  def value?(arg0)
  end

  def values
  end

  def values_at(arg0, arg1, *rest)
  end


  protected


  private

  def initialize(arg0, arg1, *rest)
  end

  def initialize_copy(arg0)
  end

end
