module DTracer


  def self.enabled?
  end

  def self.fire(arg0, arg1, *rest)
  end



  protected


  private

  def enabled?
  end

  def fire(arg0, arg1, *rest)
  end

end
