class RuntimeError < StandardError




  protected


  private

end
