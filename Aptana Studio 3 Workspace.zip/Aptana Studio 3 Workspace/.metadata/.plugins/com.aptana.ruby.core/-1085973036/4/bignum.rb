class Bignum < Integer
  include Precision
  include Comparable



  def %(arg0)
  end

  def &(arg0)
  end

  def *(arg0)
  end

  def **(arg0)
  end

  def +(arg0)
  end

  def -(arg0)
  end

  def -@
  end

  def /(arg0)
  end

  def <<(arg0)
  end

  def <=>(arg0)
  end

  def ==(arg0)
  end

  def >>(arg0)
  end

  def [](arg0)
  end

  def ^(arg0)
  end

  def abs
  end

  def coerce(arg0)
  end

  def div(arg0)
  end

  def divmod(arg0)
  end

  def eql?(arg0)
  end

  def fdiv(arg0)
  end

  def hash
  end

  def modulo(arg0)
  end

  def quo(arg0)
  end

  def remainder(arg0)
  end

  def size
  end

  def to_f
  end

  def to_s(arg0, arg1, *rest)
  end

  def |(arg0)
  end

  def ~
  end


  protected


  private

end
