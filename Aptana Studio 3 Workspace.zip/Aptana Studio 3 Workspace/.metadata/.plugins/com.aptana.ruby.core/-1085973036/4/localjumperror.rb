class LocalJumpError < StandardError



  def exit_value
  end

  def reason
  end


  protected


  private

end
