class RangeError < StandardError




  protected


  private

end
