class Continuation < Object



  def []
  end

  def call
  end


  protected


  private

end
