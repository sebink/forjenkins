module Precision


  def self.included(arg0)
  end


  def prec(arg0)
  end

  def prec_f
  end

  def prec_i
  end


  protected


  private

end
