class LoadError < ScriptError




  protected


  private

end
