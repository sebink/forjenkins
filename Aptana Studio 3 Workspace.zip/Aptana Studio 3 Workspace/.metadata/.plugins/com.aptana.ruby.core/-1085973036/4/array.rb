class Array < Object
  include Enumerable

  Enumerator = Enumerable::Enumerator

  def self.[](arg0, arg1, *rest)
  end


  def &(arg0)
  end

  def *(arg0)
  end

  def +(arg0)
  end

  def -(arg0)
  end

  def <<(arg0)
  end

  def <=>(arg0)
  end

  def ==(arg0)
  end

  def [](arg0, arg1, *rest)
  end

  def []=(arg0, arg1, *rest)
  end

  def assoc(arg0)
  end

  def at(arg0)
  end

  def choice
  end

  def clear
  end

  def collect
  end

  def collect!
  end

  def combination(arg0)
  end

  def compact
  end

  def compact!
  end

  def concat(arg0)
  end

  def count(arg0, arg1, *rest)
  end

  def cycle(arg0, arg1, *rest)
  end

  def delete(arg0)
  end

  def delete_at(arg0)
  end

  def delete_if
  end

  def drop(arg0)
  end

  def drop_while
  end

  def each
  end

  def each_index
  end

  def empty?
  end

  def eql?(arg0)
  end

  def fetch(arg0, arg1, *rest)
  end

  def fill(arg0, arg1, *rest)
  end

  def find_index(arg0, arg1, *rest)
  end

  def first(arg0, arg1, *rest)
  end

  def flatten(arg0, arg1, *rest)
  end

  def flatten!(arg0, arg1, *rest)
  end

  def frozen?
  end

  def hash
  end

  def include?(arg0)
  end

  def index(arg0, arg1, *rest)
  end

  def indexes(arg0, arg1, *rest)
  end

  def indices(arg0, arg1, *rest)
  end

  def insert(arg0, arg1, *rest)
  end

  def inspect
  end

  def join(arg0, arg1, *rest)
  end

  def last(arg0, arg1, *rest)
  end

  def length
  end

  def map
  end

  def map!
  end

  def nitems
  end

  def pack(arg0)
  end

  def permutation(arg0, arg1, *rest)
  end

  def pop(arg0, arg1, *rest)
  end

  def product(arg0, arg1, *rest)
  end

  def push(arg0, arg1, *rest)
  end

  def rassoc(arg0)
  end

  def reject
  end

  def reject!
  end

  def replace(arg0)
  end

  def reverse
  end

  def reverse!
  end

  def reverse_each
  end

  def rindex(arg0, arg1, *rest)
  end

  def select
  end

  def shift(arg0, arg1, *rest)
  end

  def shuffle
  end

  def shuffle!
  end

  def size
  end

  def slice(arg0, arg1, *rest)
  end

  def slice!(arg0, arg1, *rest)
  end

  def sort
  end

  def sort!
  end

  def take(arg0)
  end

  def take_while
  end

  def to_a
  end

  def to_ary
  end

  def to_s
  end

  def transpose
  end

  def uniq
  end

  def uniq!
  end

  def unshift(arg0, arg1, *rest)
  end

  def values_at(arg0, arg1, *rest)
  end

  def zip(arg0, arg1, *rest)
  end

  def |(arg0)
  end


  protected


  private

  def initialize(arg0, arg1, *rest)
  end

  def initialize_copy(arg0)
  end

end
