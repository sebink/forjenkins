class Dir < Object
  include Enumerable

  Enumerator = Enumerable::Enumerator
  NS_TMPDIR = "/var/folders/tc/_4c6z3l94nq_cbl0gsqy682m0000gp/T/"

  def self.[](arg0, arg1, *rest)
  end

  def self.chdir(arg0, arg1, *rest)
  end

  def self.chroot(arg0)
  end

  def self.delete(arg0)
  end

  def self.entries(arg0)
  end

  def self.foreach(arg0)
  end

  def self.getwd
  end

  def self.glob(arg0, arg1, *rest)
  end

  def self.mkdir(arg0, arg1, *rest)
  end

  def self.open(arg0)
  end

  def self.pwd
  end

  def self.rmdir(arg0)
  end

  def self.unlink(arg0)
  end


  def close
  end

  def each
  end

  def inspect
  end

  def path
  end

  def pos
  end

  def pos=
  end

  def read
  end

  def rewind
  end

  def seek
  end

  def tell
  end


  protected


  private

  def initialize
  end

end
