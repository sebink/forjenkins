class Numeric < Object
  include Comparable



  def +@
  end

  def -@
  end

  def <=>(arg0)
  end

  def abs
  end

  def ceil
  end

  def coerce(arg0)
  end

  def div(arg0)
  end

  def divmod(arg0)
  end

  def eql?(arg0)
  end

  def fdiv(arg0)
  end

  def floor
  end

  def integer?
  end

  def modulo(arg0)
  end

  def nonzero?
  end

  def quo(arg0)
  end

  def remainder(arg0)
  end

  def round
  end

  def singleton_method_added(arg0)
  end

  def step(arg0, arg1, *rest)
  end

  def to_int
  end

  def truncate
  end

  def zero?
  end


  protected


  private

  def initialize_copy(arg0)
  end

end
