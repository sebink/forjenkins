module ObjectSpace


  def self._id2ref(arg0)
  end

  def self.add_finalizer(arg0)
  end

  def self.call_finalizer(arg0)
  end

  def self.define_finalizer(arg0, arg1, *rest)
  end

  def self.each_object(arg0, arg1, *rest)
  end

  def self.finalizers
  end

  def self.garbage_collect
  end

  def self.remove_finalizer(arg0)
  end

  def self.undefine_finalizer(arg0)
  end



  protected


  private

  def _id2ref(arg0)
  end

  def add_finalizer(arg0)
  end

  def call_finalizer(arg0)
  end

  def define_finalizer(arg0, arg1, *rest)
  end

  def each_object(arg0, arg1, *rest)
  end

  def finalizers
  end

  def garbage_collect
  end

  def remove_finalizer(arg0)
  end

  def undefine_finalizer(arg0)
  end

end
