class SignalException < Exception



  def signm
  end

  def signo
  end


  protected


  private

  def initialize
  end

end
