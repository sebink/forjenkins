class TypeError < StandardError




  protected


  private

end
