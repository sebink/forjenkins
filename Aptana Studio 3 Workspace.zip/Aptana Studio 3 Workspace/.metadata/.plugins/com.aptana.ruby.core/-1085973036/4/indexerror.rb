class IndexError < StandardError




  protected


  private

end
