class SystemExit < Exception



  def status
  end

  def success?
  end


  protected


  private

  def initialize(arg0, arg1, *rest)
  end

end
