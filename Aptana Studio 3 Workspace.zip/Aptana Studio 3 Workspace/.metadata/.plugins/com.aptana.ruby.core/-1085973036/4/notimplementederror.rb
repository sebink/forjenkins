class NotImplementedError < ScriptError




  protected


  private

end
