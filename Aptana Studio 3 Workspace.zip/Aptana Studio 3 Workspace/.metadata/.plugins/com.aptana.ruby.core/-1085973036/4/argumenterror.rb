class ArgumentError < StandardError




  protected


  private

end
