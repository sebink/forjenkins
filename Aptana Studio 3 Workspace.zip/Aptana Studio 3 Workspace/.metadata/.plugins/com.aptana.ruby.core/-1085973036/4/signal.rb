module Signal


  def self.list
  end

  def self.trap(arg0, arg1, *rest)
  end



  protected


  private

  def list
  end

  def trap(arg0, arg1, *rest)
  end

end
