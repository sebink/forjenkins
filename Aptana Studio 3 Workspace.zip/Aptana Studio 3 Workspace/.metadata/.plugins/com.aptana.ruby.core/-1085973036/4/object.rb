class Object
  include Kernel

  ARGF = ARGF
  ARGV = ["/Users/sebibbaby/Documents/Aptana Studio 3 Workspace/.metadata/.plugins/com.aptana.ruby.core/-1085973036/4"]
  ArgumentError = ArgumentError
  Array = Array
  Bignum = Bignum
  Binding = Binding
  Class = Class
  Comparable = Comparable
  Continuation = Continuation
  DTracer = DTracer
  Data = Data
  Dir = Dir
  ENV = {"SHELL"=>"/bin/bash", "TMPDIR"=>"/var/folders/tc/_4c6z3l94nq_cbl0gsqy682m0000gp/T/", "SECURITYSESSIONID"=>"186a6", "__CF_USER_TEXT_ENCODING"=>"0x1F6:0:0", "PATH"=>"/usr/bin:/bin:/usr/sbin:/sbin", "COMMAND_MODE"=>"unix2003", "USER"=>"sebibbaby", "com.apple.java.jvmTask"=>"JNI", "HOME"=>"/Users/sebibbaby", "Apple_Ubiquity_Message"=>"/tmp/launch-Rt5TkX/Apple_Ubiquity_Message", "LOGNAME"=>"sebibbaby", "APP_ICON_166"=>"../Resources/aptana.icns", "Apple_PubSub_Socket_Render"=>"/tmp/launch-x5csdl/Render", "JAVA_STARTED_ON_FIRST_THREAD_166"=>"1", "SSH_AUTH_SOCK"=>"/tmp/launch-8JeQH8/Listeners"}
  EOFError = EOFError
  Enumerable = Enumerable
  Errno = Errno
  Etc = Etc
  Exception = Exception
  FALSE = false
  FalseClass = FalseClass
  File = File
  FileTest = FileTest
  FileUtils = FileUtils
  Fixnum = Fixnum
  Float = Float
  FloatDomainError = FloatDomainError
  GC = GC
  Hash = Hash
  IO = IO
  IOError = IOError
  IndexError = IndexError
  Integer = Integer
  Interrupt = Interrupt
  Kernel = Kernel
  LoadError = LoadError
  LocalJumpError = LocalJumpError
  Marshal = Marshal
  MatchData = MatchData
  MatchingData = MatchData
  Math = Math
  Method = Method
  Module = Module
  NIL = nil
  NameError = NameError
  NilClass = NilClass
  NoMemoryError = NoMemoryError
  NoMethodError = NoMethodError
  NotImplementedError = NotImplementedError
  Numeric = Numeric
  OUTPUT_PATH = "/Users/sebibbaby/Documents/Aptana Studio 3 Workspace/.metadata/.plugins/com.aptana.ruby.core/-1085973036/4/"
  Object = Object
  ObjectSpace = ObjectSpace
  PLATFORM = "universal-darwin12.0"
  Precision = Precision
  Proc = Proc
  Process = Process
  RELEASE_DATE = "2012-02-08"
  RUBY_COPYRIGHT = "ruby - Copyright (C) 1993-2012 Yukihiro Matsumoto"
  RUBY_DESCRIPTION = "ruby 1.8.7 (2012-02-08 patchlevel 358) [universal-darwin12.0]"
  RUBY_PATCHLEVEL = 358
  RUBY_PLATFORM = "universal-darwin12.0"
  RUBY_RELEASE_DATE = "2012-02-08"
  RUBY_VERSION = "1.8.7"
  Range = Range
  RangeError = RangeError
  Regexp = Regexp
  RegexpError = RegexpError
  RuntimeError = RuntimeError
  STDERR = IO.new
  STDIN = IO.new
  STDOUT = IO.new
  ScriptError = ScriptError
  SecurityError = SecurityError
  Signal = Signal
  SignalException = SignalException
  StandardError = StandardError
  StopIteration = StopIteration
  String = String
  Struct = Struct
  Symbol = Symbol
  SyntaxError = SyntaxError
  SystemCallError = SystemCallError
  SystemExit = SystemExit
  SystemStackError = SystemStackError
  TOPLEVEL_BINDING = #<Binding:0x1093feeb8>
  TRUE = true
  Thread = Thread
  ThreadError = ThreadError
  ThreadGroup = ThreadGroup
  Time = Time
  TrueClass = TrueClass
  TypeError = TypeError
  UnboundMethod = UnboundMethod
  VERSION = "1.8.7"
  ZeroDivisionError = ZeroDivisionError



  protected


  private

  def dir_names(arg0)
  end

  def file_name(arg0)
  end

  def get_classes
  end

  def grab_instance_method(arg0, arg1)
  end

  def initialize
  end

  def print_args(arg0)
  end

  def print_instance_method(arg0, arg1)
  end

  def print_method(arg0, arg1, arg2, arg3, arg4, *rest)
  end

  def print_type(arg0)
  end

  def print_value(arg0)
  end

end
