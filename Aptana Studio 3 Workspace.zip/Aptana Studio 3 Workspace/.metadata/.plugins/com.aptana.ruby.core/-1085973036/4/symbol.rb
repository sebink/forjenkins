class Symbol < Object


  def self.all_symbols
  end


  def ===(arg0)
  end

  def id2name
  end

  def inspect
  end

  def to_i
  end

  def to_int
  end

  def to_proc
  end

  def to_s
  end

  def to_sym
  end


  protected


  private

end
