class FloatDomainError < RangeError




  protected


  private

end
