class Integer < Numeric
  include Precision
  include Comparable


  def self.induced_from(arg0)
  end


  def ceil
  end

  def chr
  end

  def downto(arg0)
  end

  def even?
  end

  def floor
  end

  def integer?
  end

  def next
  end

  def odd?
  end

  def ord
  end

  def pred
  end

  def round
  end

  def succ
  end

  def times
  end

  def to_i
  end

  def to_int
  end

  def truncate
  end

  def upto(arg0)
  end


  protected


  private

end
