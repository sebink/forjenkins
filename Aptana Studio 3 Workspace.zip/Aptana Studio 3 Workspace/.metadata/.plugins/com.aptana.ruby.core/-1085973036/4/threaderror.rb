class ThreadError < StandardError




  protected


  private

end
