class NoMethodError < NameError



  def args
  end


  protected


  private

  def initialize(arg0, arg1, *rest)
  end

end
