class SystemCallError < StandardError


  def self.===(arg0)
  end


  def errno
  end


  protected


  private

  def initialize
  end

end
