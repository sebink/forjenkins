class Thread < Object


  def self.abort_on_exception
  end

  def self.abort_on_exception=(arg0)
  end

  def self.critical
  end

  def self.critical=(arg0)
  end

  def self.current
  end

  def self.exit
  end

  def self.fork(arg0, arg1, *rest)
  end

  def self.kill(arg0)
  end

  def self.list
  end

  def self.main
  end

  def self.new(arg0, arg1, *rest)
  end

  def self.pass
  end

  def self.start(arg0, arg1, *rest)
  end

  def self.stop
  end


  def []
  end

  def []=
  end

  def abort_on_exception
  end

  def abort_on_exception=
  end

  def alive?
  end

  def exit
  end

  def exit!
  end

  def group
  end

  def inspect
  end

  def join
  end

  def key?
  end

  def keys
  end

  def kill
  end

  def kill!
  end

  def priority
  end

  def priority=
  end

  def raise
  end

  def run
  end

  def safe_level
  end

  def status
  end

  def stop?
  end

  def terminate
  end

  def terminate!
  end

  def value
  end

  def wakeup
  end


  protected


  private

  def initialize
  end

end
