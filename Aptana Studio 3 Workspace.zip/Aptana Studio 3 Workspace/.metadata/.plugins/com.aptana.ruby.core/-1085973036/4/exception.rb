class Exception < Object


  def self.exception(arg0, arg1, *rest)
  end


  def backtrace
  end

  def exception(arg0, arg1, *rest)
  end

  def inspect
  end

  def message
  end

  def set_backtrace(arg0)
  end

  def to_s
  end

  def to_str
  end


  protected


  private

  def initialize(arg0, arg1, *rest)
  end

end
