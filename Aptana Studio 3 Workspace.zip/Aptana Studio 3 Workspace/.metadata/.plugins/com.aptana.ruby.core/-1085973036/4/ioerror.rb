class IOError < StandardError




  protected


  private

end
