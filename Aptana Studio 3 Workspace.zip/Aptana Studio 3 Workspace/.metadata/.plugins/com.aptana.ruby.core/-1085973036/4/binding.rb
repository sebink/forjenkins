class Binding < Object



  def clone
  end

  def dup
  end

  def eval
  end


  protected


  private

end
