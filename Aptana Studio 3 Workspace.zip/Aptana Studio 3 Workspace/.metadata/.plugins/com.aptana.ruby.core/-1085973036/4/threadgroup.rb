class ThreadGroup < Object

  Default = #<ThreadGroup:0x109418390>


  def add(arg0)
  end

  def enclose
  end

  def enclosed?
  end

  def list
  end


  protected


  private

end
