class StandardError < Exception




  protected


  private

end
