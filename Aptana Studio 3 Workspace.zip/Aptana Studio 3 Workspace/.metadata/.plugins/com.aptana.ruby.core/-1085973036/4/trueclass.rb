class TrueClass < Object



  def &(arg0)
  end

  def ^(arg0)
  end

  def to_s
  end

  def |(arg0)
  end


  protected


  private

end
