class Class < Module



  def allocate
  end

  def new(arg0, arg1, *rest)
  end

  def superclass
  end


  protected


  private

  def inherited(arg0)
  end

  def initialize(arg0, arg1, *rest)
  end

end
