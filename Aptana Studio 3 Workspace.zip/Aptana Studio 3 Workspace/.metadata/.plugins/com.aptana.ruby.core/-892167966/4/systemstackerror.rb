class SystemStackError < Exception




  protected


  private

end
