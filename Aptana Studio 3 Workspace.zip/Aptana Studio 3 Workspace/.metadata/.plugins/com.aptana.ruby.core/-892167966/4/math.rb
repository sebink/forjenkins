module Math

  DomainError = Math::DomainError
  E = 2.718281828459045
  PI = 3.141592653589793

  def self.acos(arg0)
  end

  def self.acosh(arg0)
  end

  def self.asin(arg0)
  end

  def self.asinh(arg0)
  end

  def self.atan(arg0)
  end

  def self.atan2(arg0, arg1)
  end

  def self.atanh(arg0)
  end

  def self.cbrt(arg0)
  end

  def self.cos(arg0)
  end

  def self.cosh(arg0)
  end

  def self.erf(arg0)
  end

  def self.erfc(arg0)
  end

  def self.exp(arg0)
  end

  def self.frexp(arg0)
  end

  def self.gamma(arg0)
  end

  def self.hypot(arg0, arg1)
  end

  def self.ldexp(arg0, arg1)
  end

  def self.lgamma(arg0)
  end

  def self.log(arg0, arg1, *rest)
  end

  def self.log10(arg0)
  end

  def self.log2(arg0)
  end

  def self.sin(arg0)
  end

  def self.sinh(arg0)
  end

  def self.sqrt(arg0)
  end

  def self.tan(arg0)
  end

  def self.tanh(arg0)
  end



  protected


  private

  def acos(arg0)
  end

  def acosh(arg0)
  end

  def asin(arg0)
  end

  def asinh(arg0)
  end

  def atan(arg0)
  end

  def atan2(arg0, arg1)
  end

  def atanh(arg0)
  end

  def cbrt(arg0)
  end

  def cos(arg0)
  end

  def cosh(arg0)
  end

  def erf(arg0)
  end

  def erfc(arg0)
  end

  def exp(arg0)
  end

  def frexp(arg0)
  end

  def gamma(arg0)
  end

  def hypot(arg0, arg1)
  end

  def ldexp(arg0, arg1)
  end

  def lgamma(arg0)
  end

  def log(arg0, arg1, *rest)
  end

  def log10(arg0)
  end

  def log2(arg0)
  end

  def sin(arg0)
  end

  def sinh(arg0)
  end

  def sqrt(arg0)
  end

  def tan(arg0)
  end

  def tanh(arg0)
  end

end
