class Enumerator < Object
  include Enumerable

  Generator = Enumerator::Generator
  Lazy = Enumerator::Lazy
  Yielder = Enumerator::Yielder


  def each
  end

  def each_with_index
  end

  def each_with_object
  end

  def feed
  end

  def inspect
  end

  def next
  end

  def next_values
  end

  def peek
  end

  def peek_values
  end

  def rewind
  end

  def size
  end

  def with_index
  end

  def with_object
  end


  protected


  private

  def initialize
  end

  def initialize_copy
  end

end
