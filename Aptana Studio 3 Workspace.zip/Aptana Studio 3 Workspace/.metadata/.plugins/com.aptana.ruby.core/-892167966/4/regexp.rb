class Regexp < Object

  EXTENDED = 2
  FIXEDENCODING = 16
  IGNORECASE = 1
  MULTILINE = 4
  NOENCODING = 32

  def self.compile(arg0, arg1, *rest)
  end

  def self.escape(arg0)
  end

  def self.last_match(arg0, arg1, *rest)
  end

  def self.quote(arg0)
  end

  def self.try_convert(arg0)
  end

  def self.union(arg0, arg1, *rest)
  end


  def ==
  end

  def ===
  end

  def =~
  end

  def casefold?
  end

  def encoding
  end

  def eql?
  end

  def fixed_encoding?
  end

  def hash
  end

  def inspect
  end

  def match
  end

  def named_captures
  end

  def names
  end

  def options
  end

  def source
  end

  def to_s
  end

  def ~
  end


  protected


  private

  def initialize
  end

  def initialize_copy
  end

end
