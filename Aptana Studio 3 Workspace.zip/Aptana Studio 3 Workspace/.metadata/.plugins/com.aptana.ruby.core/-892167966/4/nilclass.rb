class NilClass < Object



  def &(arg0)
  end

  def ^(arg0)
  end

  def inspect
  end

  def nil?
  end

  def rationalize(arg0, arg1, *rest)
  end

  def to_a
  end

  def to_c
  end

  def to_f
  end

  def to_h
  end

  def to_i
  end

  def to_r
  end

  def to_s
  end

  def |(arg0)
  end


  protected


  private

end
