class Queue < Object



  def <<(arg0)
  end

  def clear
  end

  def deq(arg0, arg1, *rest)
  end

  def empty?
  end

  def enq(arg0)
  end

  def length
  end

  def num_waiting
  end

  def pop(arg0, arg1, *rest)
  end

  def push(arg0)
  end

  def shift(arg0, arg1, *rest)
  end

  def size
  end


  protected


  private

  def initialize
  end

end
