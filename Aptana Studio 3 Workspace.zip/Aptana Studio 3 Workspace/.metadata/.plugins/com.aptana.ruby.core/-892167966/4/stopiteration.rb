class StopIteration < IndexError



  def result
  end


  protected


  private

end
