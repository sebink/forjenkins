class Dir < Object
  include Enumerable


  def self.[](arg0, arg1, *rest)
  end

  def self.chdir(arg0, arg1, *rest)
  end

  def self.chroot(arg0)
  end

  def self.delete(arg0)
  end

  def self.entries(arg0, arg1, *rest)
  end

  def self.exist?(arg0)
  end

  def self.exists?(arg0)
  end

  def self.foreach(arg0, arg1, *rest)
  end

  def self.getwd
  end

  def self.glob(arg0, arg1, *rest)
  end

  def self.home(arg0, arg1, *rest)
  end

  def self.mkdir(arg0, arg1, *rest)
  end

  def self.open(arg0, arg1, *rest)
  end

  def self.pwd
  end

  def self.rmdir(arg0)
  end

  def self.unlink(arg0)
  end


  def close
  end

  def each
  end

  def inspect
  end

  def path
  end

  def pos
  end

  def pos=
  end

  def read
  end

  def rewind
  end

  def seek
  end

  def tell
  end

  def to_path
  end


  protected


  private

  def initialize
  end

end
