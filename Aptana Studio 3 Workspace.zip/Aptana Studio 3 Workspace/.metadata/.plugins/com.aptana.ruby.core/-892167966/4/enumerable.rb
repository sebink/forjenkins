module Enumerable



  def all?
  end

  def any?
  end

  def chunk(arg0, arg1, *rest)
  end

  def collect
  end

  def collect_concat
  end

  def count(arg0, arg1, *rest)
  end

  def cycle(arg0, arg1, *rest)
  end

  def detect(arg0, arg1, *rest)
  end

  def drop(arg0)
  end

  def drop_while
  end

  def each_cons(arg0)
  end

  def each_entry(arg0, arg1, *rest)
  end

  def each_slice(arg0)
  end

  def each_with_index(arg0, arg1, *rest)
  end

  def each_with_object(arg0)
  end

  def entries(arg0, arg1, *rest)
  end

  def find(arg0, arg1, *rest)
  end

  def find_all
  end

  def find_index(arg0, arg1, *rest)
  end

  def first(arg0, arg1, *rest)
  end

  def flat_map
  end

  def grep(arg0)
  end

  def group_by
  end

  def include?(arg0)
  end

  def inject(arg0, arg1, *rest)
  end

  def lazy
  end

  def map
  end

  def max
  end

  def max_by
  end

  def member?(arg0)
  end

  def min
  end

  def min_by
  end

  def minmax
  end

  def minmax_by
  end

  def none?
  end

  def one?
  end

  def partition
  end

  def reduce(arg0, arg1, *rest)
  end

  def reject
  end

  def reverse_each(arg0, arg1, *rest)
  end

  def select
  end

  def slice_before(arg0, arg1, *rest)
  end

  def sort
  end

  def sort_by
  end

  def take(arg0)
  end

  def take_while
  end

  def to_a(arg0, arg1, *rest)
  end

  def zip(arg0, arg1, *rest)
  end


  protected


  private

end
