class Numeric < Object
  include Comparable



  def %(arg0)
  end

  def +@
  end

  def -@
  end

  def <=>(arg0)
  end

  def abs
  end

  def abs2
  end

  def angle
  end

  def arg
  end

  def ceil
  end

  def coerce(arg0)
  end

  def conj
  end

  def conjugate
  end

  def denominator
  end

  def div(arg0)
  end

  def divmod(arg0)
  end

  def eql?(arg0)
  end

  def fdiv(arg0)
  end

  def floor
  end

  def i
  end

  def imag
  end

  def imaginary
  end

  def integer?
  end

  def magnitude
  end

  def modulo(arg0)
  end

  def nonzero?
  end

  def numerator
  end

  def phase
  end

  def polar
  end

  def quo(arg0)
  end

  def real
  end

  def real?
  end

  def rect
  end

  def rectangular
  end

  def remainder(arg0)
  end

  def round(arg0, arg1, *rest)
  end

  def singleton_method_added(arg0)
  end

  def step(arg0, arg1, *rest)
  end

  def to_c
  end

  def to_int
  end

  def truncate
  end

  def zero?
  end


  protected


  private

  def initialize_copy(arg0)
  end

end
