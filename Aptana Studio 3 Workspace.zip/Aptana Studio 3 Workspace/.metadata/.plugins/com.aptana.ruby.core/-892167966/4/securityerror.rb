class SecurityError < Exception




  protected


  private

end
