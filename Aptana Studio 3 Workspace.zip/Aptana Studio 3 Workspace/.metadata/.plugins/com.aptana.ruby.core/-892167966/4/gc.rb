module GC

  Profiler = GC::Profiler

  def self.count
  end

  def self.disable
  end

  def self.enable
  end

  def self.start
  end

  def self.stat(arg0, arg1, *rest)
  end

  def self.stress
  end

  def self.stress=(arg0)
  end


  def garbage_collect
  end


  protected


  private

end
