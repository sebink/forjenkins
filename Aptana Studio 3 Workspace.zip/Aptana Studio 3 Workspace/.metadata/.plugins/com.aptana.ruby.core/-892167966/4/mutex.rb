class Mutex < Object



  def lock
  end

  def locked?
  end

  def owned?
  end

  def sleep(arg0, arg1, *rest)
  end

  def synchronize
  end

  def try_lock
  end

  def unlock
  end


  protected


  private

  def initialize
  end

end
