class Method < Object



  def ==
  end

  def []
  end

  def arity
  end

  def call
  end

  def clone
  end

  def eql?
  end

  def hash
  end

  def inspect
  end

  def name
  end

  def owner
  end

  def parameters
  end

  def receiver
  end

  def source_location
  end

  def to_proc
  end

  def to_s
  end

  def unbind
  end


  protected


  private

end
