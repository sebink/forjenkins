class Date < Object




  protected


  private

end
