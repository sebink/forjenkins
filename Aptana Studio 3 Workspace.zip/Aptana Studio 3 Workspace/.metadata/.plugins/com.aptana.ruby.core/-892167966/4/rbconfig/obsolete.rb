module RbConfig::Obsolete


  def self._warn_
  end

  def self.const_missing(arg0)
  end

  def self.method_missing(arg0, arg1, *rest)
  end

  def self.respond_to_missing?(arg0, arg1, *rest)
  end



  protected


  private

end
