class TracePoint < Object


  def self.new(arg0, arg1, *rest)
  end

  def self.trace(arg0, arg1, *rest)
  end


  def binding
  end

  def defined_class
  end

  def disable
  end

  def enable
  end

  def enabled?
  end

  def event
  end

  def inspect
  end

  def lineno
  end

  def method_id
  end

  def path
  end

  def raised_exception
  end

  def return_value
  end

  def self
  end


  protected


  private

end
