class Monitor < Object
  include MonitorMixin



  def enter
  end

  def exit
  end

  def try_enter
  end


  protected


  private

end
