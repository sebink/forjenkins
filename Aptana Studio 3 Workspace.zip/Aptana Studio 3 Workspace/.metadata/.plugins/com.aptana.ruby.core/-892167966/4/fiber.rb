class Fiber < Object


  def self.yield(arg0, arg1, *rest)
  end


  def resume
  end


  protected


  private

  def initialize
  end

end
