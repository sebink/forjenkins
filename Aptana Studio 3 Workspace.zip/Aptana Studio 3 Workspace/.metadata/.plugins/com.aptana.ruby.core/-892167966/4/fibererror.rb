class FiberError < StandardError




  protected


  private

end
