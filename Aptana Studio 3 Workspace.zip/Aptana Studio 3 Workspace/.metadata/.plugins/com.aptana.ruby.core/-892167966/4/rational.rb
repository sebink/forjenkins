class Rational < Numeric
  include Comparable



  def *
  end

  def **
  end

  def +
  end

  def -
  end

  def /
  end

  def <=>
  end

  def ==
  end

  def ceil
  end

  def coerce
  end

  def denominator
  end

  def fdiv
  end

  def floor
  end

  def hash
  end

  def inspect
  end

  def numerator
  end

  def quo
  end

  def rationalize
  end

  def round
  end

  def to_f
  end

  def to_i
  end

  def to_r
  end

  def to_s
  end

  def truncate
  end


  protected


  private

  def marshal_dump
  end

end
