class Integer < Numeric
  include Comparable



  def ceil
  end

  def chr(arg0, arg1, *rest)
  end

  def denominator
  end

  def downto(arg0)
  end

  def even?
  end

  def floor
  end

  def gcd(arg0)
  end

  def gcdlcm(arg0)
  end

  def integer?
  end

  def lcm(arg0)
  end

  def next
  end

  def numerator
  end

  def odd?
  end

  def ord
  end

  def pred
  end

  def rationalize(arg0, arg1, *rest)
  end

  def round(arg0, arg1, *rest)
  end

  def succ
  end

  def times
  end

  def to_bn
  end

  def to_i
  end

  def to_int
  end

  def to_r
  end

  def truncate
  end

  def upto(arg0)
  end


  protected


  private

end
