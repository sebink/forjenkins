class ConditionVariable < Object



  def broadcast
  end

  def signal
  end

  def wait(arg0, arg1, arg2, *rest)
  end


  protected


  private

  def initialize
  end

end
