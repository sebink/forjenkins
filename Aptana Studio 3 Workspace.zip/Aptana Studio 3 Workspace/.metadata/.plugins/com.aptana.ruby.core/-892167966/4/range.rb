class Range < Object
  include Enumerable



  def ==
  end

  def ===
  end

  def begin
  end

  def bsearch
  end

  def cover?
  end

  def each
  end

  def end
  end

  def eql?
  end

  def exclude_end?
  end

  def first
  end

  def hash
  end

  def include?
  end

  def inspect
  end

  def last
  end

  def max
  end

  def member?
  end

  def min
  end

  def size
  end

  def step
  end

  def to_s
  end


  protected


  private

  def initialize
  end

  def initialize_copy
  end

end
