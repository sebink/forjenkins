class Symbol < Object
  include Comparable


  def self.all_symbols
  end


  def <=>(arg0)
  end

  def ==(arg0)
  end

  def ===(arg0)
  end

  def =~(arg0)
  end

  def [](arg0, arg1, *rest)
  end

  def capitalize
  end

  def casecmp(arg0)
  end

  def downcase
  end

  def empty?
  end

  def encoding
  end

  def id2name
  end

  def inspect
  end

  def intern
  end

  def length
  end

  def match(arg0)
  end

  def next
  end

  def size
  end

  def slice(arg0, arg1, *rest)
  end

  def succ
  end

  def swapcase
  end

  def to_proc
  end

  def to_s
  end

  def to_sym
  end

  def upcase
  end


  protected


  private

end
