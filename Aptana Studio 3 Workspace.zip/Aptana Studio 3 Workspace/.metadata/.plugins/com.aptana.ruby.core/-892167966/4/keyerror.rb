class KeyError < IndexError




  protected


  private

end
