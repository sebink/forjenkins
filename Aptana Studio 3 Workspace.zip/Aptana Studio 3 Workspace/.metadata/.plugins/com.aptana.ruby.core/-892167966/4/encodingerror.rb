class EncodingError < StandardError




  protected


  private

end
