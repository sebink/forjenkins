class SizedQueue < Queue



  def <<
  end

  def clear
  end

  def deq
  end

  def enq
  end

  def max
  end

  def max=
  end

  def num_waiting
  end

  def pop
  end

  def push
  end

  def shift
  end


  protected


  private

  def initialize
  end

end
