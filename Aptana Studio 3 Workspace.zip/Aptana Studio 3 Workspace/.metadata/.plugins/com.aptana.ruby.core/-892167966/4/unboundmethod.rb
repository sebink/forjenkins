class UnboundMethod < Object



  def ==
  end

  def arity
  end

  def bind
  end

  def clone
  end

  def eql?
  end

  def hash
  end

  def inspect
  end

  def name
  end

  def owner
  end

  def parameters
  end

  def source_location
  end

  def to_s
  end


  protected


  private

end
