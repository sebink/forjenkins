class BasicObject

  BasicObject = BasicObject


  def !
  end

  def !=
  end

  def ==
  end

  def __id__
  end

  def __send__
  end

  def equal?
  end

  def instance_eval
  end

  def instance_exec
  end


  protected


  private

  def initialize
  end

  def method_missing
  end

  def singleton_method_added
  end

  def singleton_method_removed
  end

  def singleton_method_undefined
  end

end
