class MatchData < Object



  def ==(arg0)
  end

  def [](arg0, arg1, *rest)
  end

  def begin(arg0)
  end

  def captures
  end

  def end(arg0)
  end

  def eql?(arg0)
  end

  def hash
  end

  def inspect
  end

  def length
  end

  def names
  end

  def offset(arg0)
  end

  def post_match
  end

  def pre_match
  end

  def regexp
  end

  def size
  end

  def string
  end

  def to_a
  end

  def to_s
  end

  def values_at(arg0, arg1, *rest)
  end


  protected


  private

  def initialize_copy(arg0)
  end

end
