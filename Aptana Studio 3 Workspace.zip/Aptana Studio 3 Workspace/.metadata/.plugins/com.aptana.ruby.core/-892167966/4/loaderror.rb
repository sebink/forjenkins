class LoadError < ScriptError



  def path
  end


  protected


  private

end
