class Proc < Object


  def self.new(arg0, arg1, *rest)
  end


  def ===
  end

  def []
  end

  def arity
  end

  def binding
  end

  def call
  end

  def clone
  end

  def curry
  end

  def dup
  end

  def hash
  end

  def inspect
  end

  def lambda?
  end

  def parameters
  end

  def source_location
  end

  def to_proc
  end

  def to_s
  end

  def yield
  end


  protected


  private

end
