class ThreadGroup < Object

  Default = #<ThreadGroup:0x007f838989fe68>


  def add(arg0)
  end

  def enclose
  end

  def enclosed?
  end

  def list
  end


  protected


  private

end
