class Random < Object

  DEFAULT = #<Random:0x000001010688b0>

  def self.new_seed
  end

  def self.rand(arg0, arg1, *rest)
  end

  def self.srand(arg0, arg1, *rest)
  end


  def ==(arg0)
  end

  def bytes(arg0)
  end

  def rand(arg0, arg1, *rest)
  end

  def seed
  end


  protected


  private

  def initialize(arg0, arg1, *rest)
  end

  def initialize_copy(arg0)
  end

  def left
  end

  def marshal_dump
  end

  def marshal_load(arg0)
  end

  def state
  end

end
