class Complex < Numeric
  include Comparable

  I = (0+1i)
  compatible = nil

  def self.polar(arg0, arg1, *rest)
  end

  def self.rect(arg0, arg1, *rest)
  end

  def self.rectangular(arg0, arg1, *rest)
  end


  def *
  end

  def **
  end

  def +
  end

  def -
  end

  def -@
  end

  def /
  end

  def ==
  end

  def abs
  end

  def abs2
  end

  def angle
  end

  def arg
  end

  def coerce
  end

  def conj
  end

  def conjugate
  end

  def denominator
  end

  def eql?
  end

  def fdiv
  end

  def hash
  end

  def imag
  end

  def imaginary
  end

  def inspect
  end

  def magnitude
  end

  def numerator
  end

  def phase
  end

  def polar
  end

  def quo
  end

  def rationalize
  end

  def real
  end

  def real?
  end

  def rect
  end

  def rectangular
  end

  def to_c
  end

  def to_f
  end

  def to_i
  end

  def to_r
  end

  def to_s
  end


  protected


  private

  def marshal_dump
  end

end
