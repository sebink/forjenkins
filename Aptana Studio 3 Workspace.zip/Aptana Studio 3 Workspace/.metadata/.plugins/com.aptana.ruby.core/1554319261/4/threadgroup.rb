class ThreadGroup < Object

  Default = #<ThreadGroup:0x0000010105ae40>


  def add(arg0)
  end

  def enclose
  end

  def enclosed?
  end

  def list
  end


  protected


  private

end
