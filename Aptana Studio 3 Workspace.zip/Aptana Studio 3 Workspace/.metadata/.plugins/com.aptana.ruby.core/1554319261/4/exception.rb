class Exception < Object


  def self.exception(arg0, arg1, *rest)
  end


  def ==(arg0)
  end

  def backtrace
  end

  def backtrace_locations
  end

  def cause
  end

  def exception(arg0, arg1, *rest)
  end

  def inspect
  end

  def message
  end

  def respond_to?(arg0, arg1, *rest)
  end

  def set_backtrace(arg0)
  end

  def to_s
  end


  protected


  private

  def initialize(arg0, arg1, *rest)
  end

  def method_missing(arg0, arg1, *rest)
  end

  def respond_to_missing?(arg0, arg1)
  end

end
