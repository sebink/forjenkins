class Time < Object
  include Comparable

  RFC2822_DAY_NAME = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
  RFC2822_MONTH_NAME = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

  def self.at(arg0, arg1, *rest)
  end

  def self.gm(arg0, arg1, *rest)
  end

  def self.httpdate(arg0)
  end

  def self.iso8601(arg0)
  end

  def self.local(arg0, arg1, *rest)
  end

  def self.mktime(arg0, arg1, *rest)
  end

  def self.now
  end

  def self.parse(arg0, arg1, arg2, *rest)
  end

  def self.rfc2822(arg0)
  end

  def self.rfc822(arg0)
  end

  def self.strptime(arg0, arg1, arg2, arg3, *rest)
  end

  def self.utc(arg0, arg1, *rest)
  end

  def self.xmlschema(arg0)
  end

  def self.zone_offset(arg0, arg1, arg2, *rest)
  end


  def +(arg0)
  end

  def -(arg0)
  end

  def <=>(arg0)
  end

  def asctime
  end

  def ctime
  end

  def day
  end

  def dst?
  end

  def eql?(arg0)
  end

  def friday?
  end

  def getgm
  end

  def getlocal(arg0, arg1, *rest)
  end

  def getutc
  end

  def gmt?
  end

  def gmt_offset
  end

  def gmtime
  end

  def gmtoff
  end

  def hash
  end

  def hour
  end

  def httpdate
  end

  def inspect
  end

  def isdst
  end

  def iso8601(arg0, arg1, *rest)
  end

  def localtime(arg0, arg1, *rest)
  end

  def mday
  end

  def min
  end

  def mon
  end

  def monday?
  end

  def month
  end

  def nsec
  end

  def rfc2822
  end

  def rfc822
  end

  def round(arg0, arg1, *rest)
  end

  def saturday?
  end

  def sec
  end

  def strftime(arg0)
  end

  def subsec
  end

  def succ
  end

  def sunday?
  end

  def thursday?
  end

  def to_a
  end

  def to_date
  end

  def to_datetime
  end

  def to_f
  end

  def to_i
  end

  def to_r
  end

  def to_s
  end

  def to_time
  end

  def tuesday?
  end

  def tv_nsec
  end

  def tv_sec
  end

  def tv_usec
  end

  def usec
  end

  def utc
  end

  def utc?
  end

  def utc_offset
  end

  def wday
  end

  def wednesday?
  end

  def xmlschema(arg0, arg1, *rest)
  end

  def yday
  end

  def year
  end

  def zone
  end


  protected


  private

  def _dump(arg0, arg1, *rest)
  end

  def initialize(arg0, arg1, *rest)
  end

  def initialize_copy(arg0)
  end

end
