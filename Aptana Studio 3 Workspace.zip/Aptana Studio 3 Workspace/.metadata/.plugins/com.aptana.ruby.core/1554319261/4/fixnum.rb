class Fixnum < Integer
  include Comparable



  def %(arg0)
  end

  def &(arg0)
  end

  def *(arg0)
  end

  def **(arg0)
  end

  def +(arg0)
  end

  def -(arg0)
  end

  def -@
  end

  def /(arg0)
  end

  def <(arg0)
  end

  def <<(arg0)
  end

  def <=(arg0)
  end

  def <=>(arg0)
  end

  def ==(arg0)
  end

  def ===(arg0)
  end

  def >(arg0)
  end

  def >=(arg0)
  end

  def >>(arg0)
  end

  def [](arg0)
  end

  def ^(arg0)
  end

  def abs
  end

  def bit_length
  end

  def div(arg0)
  end

  def divmod(arg0)
  end

  def even?
  end

  def fdiv(arg0)
  end

  def inspect(arg0, arg1, *rest)
  end

  def magnitude
  end

  def modulo(arg0)
  end

  def odd?
  end

  def size
  end

  def succ
  end

  def to_f
  end

  def to_s(arg0, arg1, *rest)
  end

  def zero?
  end

  def |(arg0)
  end

  def ~
  end


  protected


  private

end
