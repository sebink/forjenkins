class Module < Object


  def self.constants(arg0, arg1, *rest)
  end

  def self.nesting
  end


  def <(arg0)
  end

  def <=(arg0)
  end

  def <=>(arg0)
  end

  def ==(arg0)
  end

  def ===(arg0)
  end

  def >(arg0)
  end

  def >=(arg0)
  end

  def ancestors
  end

  def autoload(arg0, arg1)
  end

  def autoload?(arg0)
  end

  def class_eval(arg0, arg1, *rest)
  end

  def class_exec(arg0, arg1, *rest)
  end

  def class_variable_defined?(arg0)
  end

  def class_variable_get(arg0)
  end

  def class_variable_set(arg0, arg1)
  end

  def class_variables(arg0, arg1, *rest)
  end

  def const_defined?(arg0, arg1, *rest)
  end

  def const_get(arg0, arg1, *rest)
  end

  def const_missing(arg0)
  end

  def const_set(arg0, arg1)
  end

  def constants(arg0, arg1, *rest)
  end

  def freeze
  end

  def include(arg0, arg1, *rest)
  end

  def include?(arg0)
  end

  def included_modules
  end

  def inspect
  end

  def instance_method(arg0)
  end

  def instance_methods(arg0, arg1, *rest)
  end

  def method_defined?(arg0)
  end

  def module_eval(arg0, arg1, *rest)
  end

  def module_exec(arg0, arg1, *rest)
  end

  def name
  end

  def prepend(arg0, arg1, *rest)
  end

  def private_class_method(arg0, arg1, *rest)
  end

  def private_constant(arg0, arg1, *rest)
  end

  def private_instance_methods(arg0, arg1, *rest)
  end

  def private_method_defined?(arg0)
  end

  def protected_instance_methods(arg0, arg1, *rest)
  end

  def protected_method_defined?(arg0)
  end

  def public_class_method(arg0, arg1, *rest)
  end

  def public_constant(arg0, arg1, *rest)
  end

  def public_instance_method(arg0)
  end

  def public_instance_methods(arg0, arg1, *rest)
  end

  def public_method_defined?(arg0)
  end

  def remove_class_variable(arg0)
  end

  def singleton_class?
  end

  def to_s
  end


  protected


  private

  def alias_method(arg0, arg1)
  end

  def append_features(arg0)
  end

  def attr(arg0, arg1, *rest)
  end

  def attr_accessor(arg0, arg1, *rest)
  end

  def attr_reader(arg0, arg1, *rest)
  end

  def attr_writer(arg0, arg1, *rest)
  end

  def define_method(arg0, arg1, *rest)
  end

  def extend_object(arg0)
  end

  def extended(arg0)
  end

  def included(arg0)
  end

  def initialize
  end

  def initialize_copy(arg0)
  end

  def method_added(arg0)
  end

  def method_removed(arg0)
  end

  def method_undefined(arg0)
  end

  def module_function(arg0, arg1, *rest)
  end

  def prepend_features(arg0)
  end

  def prepended(arg0)
  end

  def private(arg0, arg1, *rest)
  end

  def protected(arg0, arg1, *rest)
  end

  def public(arg0, arg1, *rest)
  end

  def refine(arg0)
  end

  def remove_const(arg0)
  end

  def remove_method(arg0, arg1, *rest)
  end

  def undef_method(arg0, arg1, *rest)
  end

  def using(arg0)
  end

end
