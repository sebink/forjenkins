class Binding < Object



  def clone
  end

  def dup
  end

  def eval
  end

  def local_variable_defined?
  end

  def local_variable_get
  end

  def local_variable_set
  end


  protected


  private

end
