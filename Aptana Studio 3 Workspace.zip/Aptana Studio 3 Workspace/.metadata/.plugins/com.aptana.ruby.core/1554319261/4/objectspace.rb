module ObjectSpace

  WeakMap = ObjectSpace::WeakMap

  def self._id2ref(arg0)
  end

  def self.count_objects(arg0, arg1, *rest)
  end

  def self.define_finalizer(arg0, arg1, *rest)
  end

  def self.each_object(arg0, arg1, *rest)
  end

  def self.garbage_collect(arg0, arg1, *rest)
  end

  def self.undefine_finalizer(arg0)
  end



  protected


  private

  def _id2ref(arg0)
  end

  def count_objects(arg0, arg1, *rest)
  end

  def define_finalizer(arg0, arg1, *rest)
  end

  def each_object(arg0, arg1, *rest)
  end

  def garbage_collect(arg0, arg1, *rest)
  end

  def undefine_finalizer(arg0)
  end

end
