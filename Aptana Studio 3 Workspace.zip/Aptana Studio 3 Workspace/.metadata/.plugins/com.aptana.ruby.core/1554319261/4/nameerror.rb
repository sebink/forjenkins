class NameError < StandardError

  message = nil


  def name
  end


  protected


  private

  def initialize(arg0, arg1, *rest)
  end

end
