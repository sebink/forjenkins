class String < Object
  include Comparable


  def self.try_convert(arg0)
  end


  def %(arg0)
  end

  def *(arg0)
  end

  def +(arg0)
  end

  def <<(arg0)
  end

  def <=>(arg0)
  end

  def ==(arg0)
  end

  def ===(arg0)
  end

  def =~(arg0)
  end

  def [](arg0, arg1, *rest)
  end

  def []=(arg0, arg1, *rest)
  end

  def ascii_only?
  end

  def b
  end

  def bytes
  end

  def bytesize
  end

  def byteslice(arg0, arg1, *rest)
  end

  def capitalize
  end

  def capitalize!
  end

  def casecmp(arg0)
  end

  def center(arg0, arg1, *rest)
  end

  def chars
  end

  def chomp(arg0, arg1, *rest)
  end

  def chomp!(arg0, arg1, *rest)
  end

  def chop
  end

  def chop!
  end

  def chr
  end

  def clear
  end

  def codepoints
  end

  def concat(arg0)
  end

  def count(arg0, arg1, *rest)
  end

  def crypt(arg0)
  end

  def delete(arg0, arg1, *rest)
  end

  def delete!(arg0, arg1, *rest)
  end

  def downcase
  end

  def downcase!
  end

  def dump
  end

  def each_byte
  end

  def each_char
  end

  def each_codepoint
  end

  def each_line(arg0, arg1, *rest)
  end

  def empty?
  end

  def encode(arg0, arg1, *rest)
  end

  def encode!(arg0, arg1, *rest)
  end

  def encoding
  end

  def end_with?(arg0, arg1, *rest)
  end

  def eql?(arg0)
  end

  def force_encoding(arg0)
  end

  def freeze
  end

  def getbyte(arg0)
  end

  def gsub(arg0, arg1, *rest)
  end

  def gsub!(arg0, arg1, *rest)
  end

  def hash
  end

  def hex
  end

  def include?(arg0)
  end

  def index(arg0, arg1, *rest)
  end

  def insert(arg0, arg1)
  end

  def inspect
  end

  def intern
  end

  def length
  end

  def lines(arg0, arg1, *rest)
  end

  def ljust(arg0, arg1, *rest)
  end

  def lstrip
  end

  def lstrip!
  end

  def match(arg0, arg1, *rest)
  end

  def next
  end

  def next!
  end

  def oct
  end

  def ord
  end

  def partition(arg0)
  end

  def prepend(arg0)
  end

  def replace(arg0)
  end

  def reverse
  end

  def reverse!
  end

  def rindex(arg0, arg1, *rest)
  end

  def rjust(arg0, arg1, *rest)
  end

  def rpartition(arg0)
  end

  def rstrip
  end

  def rstrip!
  end

  def scan(arg0)
  end

  def scrub(arg0, arg1, *rest)
  end

  def scrub!(arg0, arg1, *rest)
  end

  def setbyte(arg0, arg1)
  end

  def size
  end

  def slice(arg0, arg1, *rest)
  end

  def slice!(arg0, arg1, *rest)
  end

  def split(arg0, arg1, *rest)
  end

  def squeeze(arg0, arg1, *rest)
  end

  def squeeze!(arg0, arg1, *rest)
  end

  def start_with?(arg0, arg1, *rest)
  end

  def strip
  end

  def strip!
  end

  def sub(arg0, arg1, *rest)
  end

  def sub!(arg0, arg1, *rest)
  end

  def succ
  end

  def succ!
  end

  def sum(arg0, arg1, *rest)
  end

  def swapcase
  end

  def swapcase!
  end

  def to_c
  end

  def to_f
  end

  def to_i(arg0, arg1, *rest)
  end

  def to_r
  end

  def to_s
  end

  def to_str
  end

  def to_sym
  end

  def tr(arg0, arg1)
  end

  def tr!(arg0, arg1)
  end

  def tr_s(arg0, arg1)
  end

  def tr_s!(arg0, arg1)
  end

  def unpack(arg0)
  end

  def upcase
  end

  def upcase!
  end

  def upto(arg0, arg1, *rest)
  end

  def valid_encoding?
  end


  protected


  private

  def initialize(arg0, arg1, *rest)
  end

  def initialize_copy(arg0)
  end

end
