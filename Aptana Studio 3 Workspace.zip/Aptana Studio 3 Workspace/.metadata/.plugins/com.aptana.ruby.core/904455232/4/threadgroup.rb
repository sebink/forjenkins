class ThreadGroup < Object

  Default = #<ThreadGroup:0x007f831c09fe38>


  def add(arg0)
  end

  def enclose
  end

  def enclosed?
  end

  def list
  end


  protected


  private

end
