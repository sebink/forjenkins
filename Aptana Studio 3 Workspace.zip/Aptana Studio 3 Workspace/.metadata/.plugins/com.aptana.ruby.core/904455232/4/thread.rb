class Thread < Object

  Backtrace = Thread::Backtrace
  MUTEX_FOR_THREAD_EXCLUSIVE = #<Mutex:0x007f831c096810>

  def self.abort_on_exception
  end

  def self.abort_on_exception=(arg0)
  end

  def self.current
  end

  def self.exclusive
  end

  def self.exit
  end

  def self.fork(arg0, arg1, *rest)
  end

  def self.handle_interrupt(arg0)
  end

  def self.kill(arg0)
  end

  def self.list
  end

  def self.main
  end

  def self.new(arg0, arg1, *rest)
  end

  def self.pass
  end

  def self.pending_interrupt?(arg0, arg1, *rest)
  end

  def self.start(arg0, arg1, *rest)
  end

  def self.stop
  end


  def []
  end

  def []=
  end

  def abort_on_exception
  end

  def abort_on_exception=
  end

  def add_trace_func
  end

  def alive?
  end

  def backtrace
  end

  def backtrace_locations
  end

  def exit
  end

  def group
  end

  def inspect
  end

  def join
  end

  def key?
  end

  def keys
  end

  def kill
  end

  def pending_interrupt?
  end

  def priority
  end

  def priority=
  end

  def raise
  end

  def run
  end

  def safe_level
  end

  def set_trace_func
  end

  def status
  end

  def stop?
  end

  def terminate
  end

  def thread_variable?
  end

  def thread_variable_get
  end

  def thread_variable_set
  end

  def thread_variables
  end

  def value
  end

  def wakeup
  end


  protected


  private

  def initialize
  end

end
